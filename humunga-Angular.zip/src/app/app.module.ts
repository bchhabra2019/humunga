import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { TourComponent } from './tour/tour.component';
import { ExamplesComponent } from './examples/examples.component'
import { UpgradeComponent } from './upgrade/upgrade.component';
import { FooterComponent } from './footer/footer.component';
import { AppRoutingModule } from './app-routing.module';
import { FeaturelistComponent } from './featurelist/featurelist.component';
import { ToolsComponent } from './tools/tools.component';
import { CareersComponent } from './careers/careers.component';
import { HelpComponent } from './help/help.component';
import { TermsComponent } from './terms/terms.component';
import { PolicyComponent } from './policy/policy.component';
import { MobileComponent } from './mobile/mobile.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { AlbumListComponent } from './album-list/album-list.component';
import { AlbumDetailsComponent } from './album-details/album-details.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    AboutComponent,
    TourComponent,
    ExamplesComponent,
    UpgradeComponent,
    FooterComponent,
    FeaturelistComponent,
    ToolsComponent,
    CareersComponent,
    HelpComponent,
    TermsComponent,
    PolicyComponent,
    MobileComponent,
    LoginComponent,
    SignupComponent,
    AlbumListComponent,
    AlbumDetailsComponent       
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
