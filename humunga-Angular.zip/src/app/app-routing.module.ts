import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { TourComponent } from './tour/tour.component';
import { ExamplesComponent } from './examples/examples.component';
import { UpgradeComponent } from './upgrade/upgrade.component';
import { MobileComponent } from './mobile/mobile.component';
import { FeaturelistComponent } from './featurelist/featurelist.component';
import { ToolsComponent } from './tools/tools.component';
import { CareersComponent } from './careers/careers.component';
import { HelpComponent } from './help/help.component';
import { TermsComponent } from './terms/terms.component';
import { PolicyComponent } from './policy/policy.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { AlbumListComponent } from './album-list/album-list.component';
import { AlbumDetailsComponent } from './album-details/album-details.component';


const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'header', component: HeaderComponent },
  { path: 'footer', component: FooterComponent },
  { path: 'home', component: HomeComponent },
  { path: 'about', component: AboutComponent },
  { path: 'tour', component: TourComponent },
  { path: 'examples', component: ExamplesComponent },
  { path: 'upgrade', component: UpgradeComponent },
  { path: 'mobile', component: MobileComponent },
  { path: 'featurelist', component: FeaturelistComponent },
  { path: 'tools', component: ToolsComponent },
  { path: 'careers', component: CareersComponent },
  { path: 'help', component: HelpComponent },
  { path: 'terms', component: TermsComponent },
  { path: 'policy', component: PolicyComponent },
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'album-list', component: AlbumListComponent },
  { path: 'album-details', component: AlbumDetailsComponent }
];


@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forRoot(routes)]
})
export class AppRoutingModule { }