import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-featurelist',
  templateUrl: './featurelist.component.html',
  styleUrls: ['./featurelist.component.css']
})
export class FeaturelistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
