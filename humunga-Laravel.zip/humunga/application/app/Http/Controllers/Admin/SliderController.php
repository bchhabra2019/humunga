<?php

namespace App\Http\Controllers\Admin;

use DB;
use App\Slider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class SliderController extends Controller
{
	public function __construct()
    {
        $this->middleware('auth');
    }	
	
    public function index()
	{
		$slider_resut = Slider::all();
		$pageInfo = [
			'page_title'=>'Slider',
			'menuId' => 'Slider',
			'slider_resut' => $slider_resut
		];
		
        return view('Admin.slider')->with($pageInfo);
	}
	
	/**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
		$pageInfo = [
			'page_title' => 'Slider',
			'menuId' => 'Slider'
		];
        return view('Admin.slider_create')->with($pageInfo);
    }
	
	/**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {		
        request()->validate([
            'status' => 'required',
            'type' => 'required'
        ]);
	
		if ($request->hasFile('icon')) {			
			$image = $request->file('icon');
			$names = 'icon_'.rand(10,1000).''.time().'.'.$image->getClientOriginalExtension();
			$destinationPath = public_path('/admin/images');
			$image->move($destinationPath, $names);
			$data['icon'] = $names;
		}
		if ($request->hasFile('image')) {			
			$images = $request->file('image');
			$name = 'image_'.rand(10,1000).''.time().'.'.$images->getClientOriginalExtension();
			$destinationPath = public_path('/admin/images');
			$images->move($destinationPath, $name);
			$data['image'] = $name;
		}
	
		$data['status'] = $request->input('status');
		$data['description'] = $request->input('description');
		$data['type'] = $request->input('type');
		$data['title'] = $request->input('title');
		
        Slider::create($data);	
		
        return redirect()->route('slider.index')
                        ->with('success','Slider details are stored successfully.');
    }
	
	/**
     * Display the specified resource.
     *
     * @param  \App\Slider  $Slider
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
		$slider_details = Slider::find($id);
		$pageInfo = [
			'page_title' => 'Show Slider',
			'menuId' => 'Slider',
			'slider_details' => $slider_details
		];
        return view('Admin.slider_show')->with($pageInfo);
    }
			
	 /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Slider  $Slider
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
		$slider_details = Slider::find($id);
		$pageInfo = [
			'page_title' => 'Edit Slider',
			'menuId' => 'Slider',
			'slider_details' => $slider_details
		];
        return view('Admin.slider_edit')->with($pageInfo);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Slider  $Slider
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        request()->validate([
            'status' => 'required',	
            'type' => 'required'	
        ]);

		$details = Slider::find($id);
		
		$image_logo = '';
		if ($request->hasFile('icon')) {
			$image_path = "admin/images/".$details->icon;
			//unlink($image_path);
			$image = $request->file('icon');
			$name = 'icon_'.rand(10,1000).''.time().'.'.$image->getClientOriginalExtension();
			$destinationPath = public_path('/admin/images');
			$image->move($destinationPath, $name);
			$details->icon = $name;
		}
		if ($request->hasFile('image')) {
			$image_path = "admin/images/".$details->image;
			//unlink($image_path);
			$images = $request->file('image');
			$namee = 'image_'.rand(10,1000).''.time().'.'.$images->getClientOriginalExtension();
			$destinationPaths = public_path('/admin/images');
			$images->move($destinationPaths, $namee);
			$details->image = $namee;
		}
		$details->type = $request->post('type');
		$details->description = $request->post('description');
		$details->status = $request->post('status');
		$details->title = $request->post('title');
		$details->save();

        return redirect()->route('slider.index')
                        ->with('success', 'Details are updated successfully');
    }
	
	/**
     * Remove the specified resource from storage.
     *
     * @param  \App\Systempages  $Systempages
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
		DB::delete('delete from sliders where id = ?',[$id]);
        return redirect()->route('slider.index')
                        ->with('success','Slider details remove successfully');
    }
}
