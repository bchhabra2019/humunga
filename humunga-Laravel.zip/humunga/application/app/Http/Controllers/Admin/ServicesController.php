<?php

namespace App\Http\Controllers\Admin;

use DB;
use App\Services;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class ServicesController extends Controller
{
	public function __construct()
    {
        $this->middleware('auth');
    }	
	
    public function index()
	{
		$services_resut = Services::all();
		$pageInfo = [
			'page_title'=>'Services',
			'menuId' => 'Services',
			'services_resut' => $services_resut
		];
		
        return view('Admin.services')->with($pageInfo);
	}
	
	/**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
		$pageInfo = [
			'page_title' => 'Services',
			'menuId' => 'Services'
		];
        return view('Admin.services_create')->with($pageInfo);
    }
	
	/**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {		
        request()->validate([
            'status' => 'required',
            'type' => 'required'
        ]);
	
		if ($request->hasFile('icon')) {			
			$image = $request->file('icon');
			$names = 'icon_'.rand(10,1000).''.time().'.'.$image->getClientOriginalExtension();
			$destinationPath = public_path('/admin/images');
			$image->move($destinationPath, $names);
			$data['icon'] = $names;
		}
		if ($request->hasFile('image')) {			
			$images = $request->file('image');
			$name = 'image_'.rand(10,1000).''.time().'.'.$images->getClientOriginalExtension();
			$destinationPath = public_path('/admin/images');
			$images->move($destinationPath, $name);
			$data['image'] = $name;
		}
	
		$data['status'] = $request->input('status');
		$data['type'] = $request->input('type');
		$data['title'] = $request->input('title');
		
        Services::create($data);	
		
        return redirect()->route('services.index')
                        ->with('success','Services details are stored successfully.');
    }
	
	/**
     * Display the specified resource.
     *
     * @param  \App\Services  $Services
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
		$services_details = Services::find($id);
		$pageInfo = [
			'page_title' => 'Show Services',
			'menuId' => 'Services',
			'services_details' => $services_details
		];
        return view('Admin.services_show')->with($pageInfo);
    }
			
	 /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Services  $Services
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
		$services_details = Services::find($id);
		$pageInfo = [
			'page_title' => 'Edit Services',
			'menuId' => 'Services',
			'services_details' => $services_details
		];
        return view('Admin.services_edit')->with($pageInfo);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Services  $Services
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        request()->validate([
            'name' => 'required',	
            'description' => 'required'	
        ]);

		$details = Services::find($id);
		
		$image_logo = '';
		if ($request->hasFile('icon')) {
			$image_path = "admin/images/".$details->icon;
			//unlink($image_path);
			$image = $request->file('icon');
			$name = 'icon_'.rand(10,1000).''.time().'.'.$image->getClientOriginalExtension();
			$destinationPath = public_path('/admin/images');
			$image->move($destinationPath, $name);
			$details->icon = $name;
		}
		
		$details->name = $request->post('name');
		$details->description = $request->post('description');
		$details->save();

        return redirect()->route('services.index')
                        ->with('success', 'Details are updated successfully');
    }
	
	/**
     * Remove the specified resource from storage.
     *
     * @param  \App\Systempages  $Systempages
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
		DB::delete('delete from services where id = ?',[$id]);
        return redirect()->route('services.index')
                        ->with('success','Services details remove successfully');
    }
}
