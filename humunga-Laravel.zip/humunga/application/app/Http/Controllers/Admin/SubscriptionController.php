<?php

namespace App\Http\Controllers\Admin;

use DB;
use App\Subscription;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class SubscriptionController extends Controller
{
	public function __construct()
    {
        $this->middleware('auth');
    }	
	
    public function index()
	{
		$subscriptions = Subscription::latest()->paginate(5);
		$ii = ((request()->input('page', 1) - 1) * 5);
		$pageInfo = [
			'page_title'=>'Subscription',
			'menuId' => 'Subscription',
			'subscriptions' => $subscriptions,
			'i' => $ii
		];
        return view('Admin.subscription')->with($pageInfo);		
	}
	
	/**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
		$pageInfo = [
			'page_title' => 'Subscription',
			'menuId' => 'Subscription'
		];
        return view('Admin.subscription_create')->with($pageInfo);
    }
	
	/**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate([
            'name' => 'required',
            'heading' => 'required',
			'data_space' => 'required',
            'duration' => 'required',
            'description' => 'required',
            'price' => 'required|numeric',
            'offer_percent1' => 'numeric|between:0,99.99',
            'offer_percent2' => 'numeric|between:0,99.99',
            'offer_percent3' => 'numeric|between:0,99.99'
        ]);

		$postData['name'] = $request->input('name');
		$postData['heading'] = $request->input('heading');
		$postData['data_space'] = $request->input('data_space');
		$postData['duration'] = $request->input('duration');
		$postData['description'] = $request->input('description');
		$postData['price'] = $request->input('price');
		
		$offer_percent1 = $request->input('offer_percent1');
		if($offer_percent1 != '')
		{
			$postData['offer_percent1'] = $offer_percent1;
			$postData['offer_duration1'] = $request->input('offer_duration1');
			$postData['offer_expiry1'] = $request->input('offer_expiry1');
		}
		else
		{
			$postData['offer_percent1'] = 0;
			$postData['offer_duration1'] = 0;
			$postData['offer_expiry1'] = 0;
		}
		$offer_percent2 = $request->input('offer_percent2');
		if($offer_percent2 != '')
		{
			$postData['offer_percent2'] = $offer_percent2;
			$postData['offer_duration2'] = $request->input('offer_duration2');
			$postData['offer_expiry2'] = $request->input('offer_expiry2');
		}
		else
		{
			$postData['offer_percent2'] = 0;
			$postData['offer_duration2'] = 0;
			$postData['offer_expiry2'] = 0;
		}
		$offer_percent3 = $request->input('offer_percent3');
		if($offer_percent3 != '')
		{
			$postData['offer_percent3'] = $offer_percent3;
			$postData['offer_duration3'] = $request->input('offer_duration3');
			$postData['offer_expiry3'] = $request->input('offer_expiry3');
		}
		else
		{
			$postData['offer_percent3'] = 0;
			$postData['offer_duration3'] = 0;
			$postData['offer_expiry3'] = 0;
		}

        Subscription::create($postData);

        return redirect()->route('subscription.index')
                        ->with('success','Subscription created successfully.');
    }
	
	/**
     * Display the specified resource.
     *
     * @param  \App\Subscription  $Subscription
     * @return \Illuminate\Http\Response
     */
    public function show(Subscription $subscription)
    {
		$pageInfo = [
			'page_title' => 'Subscription',
			'menuId' => 'Subscription',
			'subscription' => $subscription
		];
        return view('Admin.subscription_show')->with($pageInfo);
    }
	
	 /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Subscription  $Subscription
     * @return \Illuminate\Http\Response
     */
    public function edit(Subscription $Subscription)
    {
		$pageInfo = [
			'page_title' => 'Subscription',
			'menuId' => 'Subscription',
			'subscription' => $Subscription
		];
        return view('Admin.subscription_edit')->with($pageInfo);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Subscription  $Subscription
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Subscription $Subscription)
    {
        request()->validate([
            'name' => 'required',
            'price' => 'required|numeric',
            'data_space' => 'required',
            'duration' => 'required',
            'heading' => 'required',
            'description' => 'required',
			'price' => 'required|numeric',
            'offer_percent1' => 'numeric|between:0,99.99',
            'offer_percent2' => 'numeric|between:0,99.99',
            'offer_percent3' => 'numeric|between:0,99.99'
        ]);

		$postData['name'] = $request->input('name');
		$postData['heading'] = $request->input('heading');
		$postData['data_space'] = $request->input('data_space');
		$postData['duration'] = $request->input('duration');
		$postData['description'] = $request->input('description');
		$postData['price'] = $request->input('price');
		
		$offer_percent1 = $request->input('offer_percent1');
		if($offer_percent1 != '')
		{
			$postData['offer_percent1'] = $offer_percent1;
			$postData['offer_duration1'] = $request->input('offer_duration1');
			$postData['offer_expiry1'] = $request->input('offer_expiry1');
		}
		else
		{
			$postData['offer_percent1'] = 0;
			$postData['offer_duration1'] = 0;
			$postData['offer_expiry1'] = 0;
		}
		$offer_percent2 = $request->input('offer_percent2');
		if($offer_percent2 != '')
		{
			$postData['offer_percent2'] = $offer_percent2;
			$postData['offer_duration2'] = $request->input('offer_duration2');
			$postData['offer_expiry2'] = $request->input('offer_expiry2');
		}
		else
		{
			$postData['offer_percent2'] = 0;
			$postData['offer_duration2'] = 0;
			$postData['offer_expiry2'] = 0;
		}
		$offer_percent3 = $request->input('offer_percent3');
		if($offer_percent3 != '')
		{
			$postData['offer_percent3'] = $offer_percent3;
			$postData['offer_duration3'] = $request->input('offer_duration3');
			$postData['offer_expiry3'] = $request->input('offer_expiry3');
		}
		else
		{
			$postData['offer_percent3'] = 0;
			$postData['offer_duration3'] = 0;
			$postData['offer_expiry3'] = 0;
		}

        $Subscription->update($postData);

        return redirect()->route('subscription.index')
                        ->with('success','Subscription details are updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Subscription $Subscription)
    {
        $Subscription->delete();

        return redirect()->route('subscription.index')
                        ->with('success','Subscription details deleted successfully');
    }
	
	/**
	*	Set status	
	*/
	public function set_status(Request $request)
	{		
		$subscription = Subscription::find($request->get('id'));
		$subscription->status = $request->get('status');
		$subscription->save();
		
		echo 1;
		exit();
	}
}
