<?php

namespace App\Http\Controllers\Admin;

use DB;
use App\Website_details;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class WebsiteSettingController extends Controller
{
	public function __construct()
    {
        $this->middleware('auth');
    }	
	
    public function index()
	{
		$websiteSetting = Website_details::all();
		$pageInfo = [
			'page_title'=>'Website Setting',
			'menuId' => 'Websitesetting',
			'websitesetting' => $websiteSetting
		];
		
        return view('Admin.websitesetting')->with($pageInfo);
	}
	
	/**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
		return redirect()->route('websitesetting.index')
                        ->with('success',$data['name'].' Not allow');
    }
			
	 /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Websitesetting  $Websitesetting
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
		$websitesetting_details = Website_details::find($id);
		$pageInfo = [
			'page_title' => 'Website Setting',
			'menuId' => 'Websitesetting',
			'websitesetting_details' => $websitesetting_details
		];
        return view('Admin.websitesetting_edit')->with($pageInfo);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Websitesetting  $Websitesetting
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        request()->validate([
            'email' => 'required',			
            'phone' => 'required|numeric|digits:10',			
            'skype_address' => 'required'		
        ]);

		$details = Website_details::find($id);
		
		$image_logo = '';
		if ($request->hasFile('logo')) {
			$image_path = "admin/images/".$details->logo;
			unlink($image_path);
			$image = $request->file('logo');
			$name = time().'.'.$image->getClientOriginalExtension();
			$destinationPath = public_path('/admin/images');
			$image->move($destinationPath, $name);
			$image_logo = $image;
			$details->logo = $name;
		}
		$details->email = $request->post('email');
		$details->phone = $request->post('phone');
		$details->address = $request->post('address');
		$details->skype_address = $request->post('skype_address');
		$details->save();

        return redirect()->route('websitesetting.index')
                        ->with('success', 'Details are updated successfully');
    }
}
