<?php

namespace App\Http\Controllers\Admin;

use DB;
use App\Systempages;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class SystempagesController extends Controller
{
	public function __construct()
    {
        $this->middleware('auth');
    }	
	
    public function index()
	{
		$systempages = Systempages::latest()->paginate(5);
		$ii = ((request()->input('page', 1) - 1) * 5);
		$pageInfo = [
			'page_title'=>'System Email',
			'menuId' => 'Systempages',
			'systempages' => $systempages,
			'i' => $ii
		];
		
        return view('Admin.systempages')->with($pageInfo);
	}
	
	/**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
		$pageInfo = [
			'page_title' => 'Systempages',
			'menuId' => 'Systempages'
		];
        return view('Admin.systempages_create')->with($pageInfo);
    }
	
	/**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate([
            'name' => 'required|unique:systempages,name',
            'heading' => 'required',
            'description' => 'required'
        ]);
	
		$data['name'] = $request->input('name');
		$data['heading'] = $request->input('heading');
		$description = $request->input('description');
		$data['description'] = $description;
		
        Systempages::create($data);	
		
        return redirect()->route('systempages.index')
                        ->with('success',$data['name'].' created successfully.');
    }
	
	/**
     * Display the specified resource.
     *
     * @param  \App\Systempages  $Systempages
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
		$systempages_details = Systempages::find($id);
		$pageInfo = [
			'page_title' => $systempages_details->name,
			'menuId' => 'Systempages',
			'systempages_details' => $systempages_details
		];
        return view('Admin.systempages_show')->with($pageInfo);
    }
	
	 /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Systempages  $Systempages
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
		$systempages_details = Systempages::find($id);
		$pageInfo = [
			'page_title' => $systempages_details->name,
			'menuId' => 'Systempages',
			'systempages_details' => $systempages_details
		];
        return view('Admin.systempages_edit')->with($pageInfo);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Systempages  $Systempages
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        request()->validate([
            'name' => 'required',			
            'heading' => 'required',			
            'description' => 'required'		
        ]);

		$member = Systempages::find($id);
		$member->name = $request->post('name');
		$member->heading = $request->post('heading');
		$member->description = $request->post('description');
		$member->save();

        return redirect()->route('systempages.index')
                        ->with('success',$request->post('name').' are updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Systempages  $Systempages
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
		DB::delete('delete from systempages where id = ?',[$id]);
        return redirect()->route('systempages.index')
                        ->with('success','System details remove successfully');
    }
}
