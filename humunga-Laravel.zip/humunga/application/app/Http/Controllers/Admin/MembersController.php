<?php

namespace App\Http\Controllers\Admin;

use DB;
use Mail;
use App\Members;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class MembersController extends Controller
{
	public function __construct()
    {
        $this->middleware('auth');
    }	
	
    public function index()
	{
		$selected_plan = DB::table('user_plan_details')->get();
		$members = Members::latest()->paginate(5);
		$ii = ((request()->input('page', 1) - 1) * 5);
		$pageInfo = [
			'page_title'=>'Members',
			'menuId' => 'Members',
			'member' => $members,
			'plan_details' => $selected_plan,
			'i' => $ii
		];
		
        return view('Admin.member')->with($pageInfo);
	}
	
	/**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
		$pageInfo = [
			'page_title' => 'Members',
			'menuId' => 'Members'
		];
        return view('Admin.members_create')->with($pageInfo);
    }
	
	/**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate([
            'name' => 'required',
            'email' => 'required|unique:members,email'
        ]);
	
		$data['name'] = $request->input('name');
		
		$data['business'] = @$request->input('business');
		$data['website'] = @$request->input('website');
		$data['biography'] = @$request->input('biography');
		$data['phone'] = @$request->input('phone');
		$data['country'] = @$request->input('country');
		$data['facebook'] = @$request->input('facebook');
		$data['instagram'] = @$request->input('instagram');
		$data['yt_link'] = @$request->input('yt_link');
		$data['vimeo'] = @$request->input('vimeo');
		$data['linkedin'] = @$request->input('linkedin');
		
		$data['email'] = $request->input('email');
		$user_email = $request->input('email');
		$data['referral_code'] = sha1($request->input('name').''.$request->input('email').''.time());
		$password = str_random(7);		
		$data['password'] = sha1($password);
		
		if ($request->hasFile('image')) {			
			$image = $request->file('image');
			$name = $data['name'].'_'.rand(99, 99999).time().'.'.$image->getClientOriginalExtension();
			$destinationPath = public_path('/admin/images');
			$image->move($destinationPath, $name);
			$data['image'] = $name;
		}
		
        Members::create($data);	

		$datas = array(
			'heading' => "Registration successfully!",
			'subject' => "Registration successful on Humunga",
			'name' => $data["name"],
			'Email' => $data["email"],
			'Password' => $password
		);
	
		$subject = 'Registration successfully!';	
		$email = $data['email'];	

		$message = view('Admin.email_temp')->with($datas);
		
		$url = 'https://api.sendgrid.com/';
		$user = 'Humunga';
		$pass = 'humunga@2019';
		$params = array(
			'api_user'  => $user,
			'api_key'   => $pass,
			'to'        => $email,
			'subject'   => $subject,
			'html'      => $message,
			'from'      => 'humunga@redmapple.com',
		  );
		$request =  $url.'api/mail.send.json';
		// Generate curl request
		$session = curl_init($request);
		// Tell curl to use HTTP POST
		curl_setopt ($session, CURLOPT_POST, true);
		// Tell curl that this is the body of the POST
		curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
		// Tell curl not to return headers, but do return the response
		curl_setopt($session, CURLOPT_HEADER, false);
		// Tell PHP not to use SSLv3 (instead opting for TLS)
		curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
		curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

		// obtain response
		$response = curl_exec($session);
		//var_dump($response);
		curl_close($session);

		/*
		Mail::send('Admin.email', $datas, function ($message) use ($datas) {

			$message->from('info@humunga.com', 'Humunga');

			$message->to($datas['Email'], $datas['name'])->subject('Registration successful on Humunga');

		});
		*/
		
        return redirect()->route('members.index')
                        ->with('success','Member created successfully.');
    }
	
	/**
     * Display the specified resource.
     *
     * @param  \App\Members  $Members
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
		$selected_plan = DB::table('user_plan_details')->where('user_id', $id)->first();
		
		$Members_details = Members::find($id);
		$pageInfo = [
			'page_title' => 'Members',
			'menuId' => 'Members',
			'member' => $Members_details,
			'plan_details' => $selected_plan
		];
        return view('Admin.members_show')->with($pageInfo);
    }
	
	 /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Members  $Members
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
		$member_details = Members::find($id);
		$pageInfo = [
			'page_title' => 'Members',
			'menuId' => 'Members',
			'member' => $member_details
		];
        return view('Admin.members_edit')->with($pageInfo);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Users  $Users
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        request()->validate([
            'name' => 'required'			
        ]);

		$member = Members::find($id);
		$member->name = $request->post('name');
		
		$member->business = @$request->input('business');
		$member->website = @$request->input('website');
		$member->biography = @$request->input('biography');
		$member->phone = @$request->input('phone');
		$member->country = @$request->input('country');
		$member->facebook = @$request->input('facebook');
		$member->instagram = @$request->input('instagram');
		$member->yt_link = @$request->input('yt_link');
		$member->vimeo = @$request->input('vimeo');
		$member->linkedin = @$request->input('linkedin');
		
		if ($request->hasFile('image')) {
			$image_path = "admin/images/".$member->image;
			unlink($image_path);
			$image = $request->file('image');
			$namee = time().'.'.$image->getClientOriginalExtension();
			$destinationPath = public_path('/admin/images');
			$image->move($destinationPath, $namee);
			$member->image = $namee;
		}
		
		$member->save();

        return redirect()->route('members.index')
                        ->with('success','Member details are updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Members  $Members
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
		DB::delete('delete from members where id = ?',[$id]);
		DB::delete('delete from user_plan_details where user_id = ?',[$id]);
        return redirect()->route('members.index')
                        ->with('success','Members details deleted successfully');
    }
	
	/*
	* ------------------------------
	*	@ Ajax search form
	* --------------------------------------------------
	*/
	public function search_ajax(Request $request)
	{
		$userEmail = $request->get('email');
		$user_details = DB::table('members')->where('email',$userEmail)->get();
		
		if($user_details[0]->email)
		{
			echo 'ok';
			exit();
		}
		else
		{
			echo '';
			exit();
		}			
	}
}
