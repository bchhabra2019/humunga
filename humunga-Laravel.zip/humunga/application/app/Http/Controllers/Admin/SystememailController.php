<?php

namespace App\Http\Controllers\Admin;

use DB;
use App\Systememail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class SystememailController extends Controller
{
	public function __construct()
    {
        $this->middleware('auth');
    }	
	
    public function index()
	{
		$systememail = Systememail::latest()->paginate(5);
		$ii = ((request()->input('page', 1) - 1) * 5);
		$pageInfo = [
			'page_title'=>'System Email',
			'menuId' => 'Systememail',
			'systememails' => $systememail,
			'i' => $ii
		];
		
        return view('Admin.systememail')->with($pageInfo);
	}
	
	/**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
		$pageInfo = [
			'page_title' => 'Systememail',
			'menuId' => 'Systememail'
		];
        return view('Admin.systememail_create')->with($pageInfo);
    }
	
	/**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate([
            'title' => 'required|unique:systememails,title',
            'subject' => 'required',
            'message' => 'required'
        ]);
	
		$data['title'] = $request->input('title');
		$data['subject'] = $request->input('subject');
		$message = $request->input('message');
		$data['message'] = $message;
		
        Systememail::create($data);	
				
        return redirect()->route('systememail.index')
                        ->with('success',$data['title'].' email template created successfully.');
    }
	
	/**
     * Display the specified resource.
     *
     * @param  \App\Systememail  $Systememail
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
		$Systememail_details = Systememail::find($id);
		$pageInfo = [
			'page_title' => 'System Email',
			'menuId' => 'Systememail',
			'systememails' => $Systememail_details
		];
        return view('Admin.systememail_show')->with($pageInfo);
    }
	
	 /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Systememail  $Systememail
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
		$system_details = Systememail::find($id);
		$pageInfo = [
			'page_title' => 'system email',
			'menuId' => 'Systememail',
			'system_details' => $system_details
		];
        return view('Admin.systememail_edit')->with($pageInfo);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Systememail  $Systememail
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        request()->validate([
            'title' => 'required',			
            'subject' => 'required',			
            'message' => 'required'		
        ]);

		$member = Systememail::find($id);
		$member->title = $request->post('title');
		$member->subject = $request->post('subject');
		$member->message = $request->post('message');
		$member->save();

        return redirect()->route('systememail.index')
                        ->with('success',$request->post('title').' template are updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Systememail  $Systememail
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
		DB::delete('delete from systememails where id = ?',[$id]);
        return redirect()->route('systememail.index')
                        ->with('success','System email template details remove successfully');
    }
}
