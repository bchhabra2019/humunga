<?php

namespace App\Http\Controllers\Admin;

use DB;
use App\Home_sections;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class HomeSectionController extends Controller
{
	public function __construct()
    {
        $this->middleware('auth');
    }	
	
    public function index()
	{
		$services_resut = Home_sections::all();
		$pageInfo = [
			'page_title'=>'Home sections',
			'menuId' => 'Sections',
			'services_resut' => $services_resut
		];
		
        return view('Admin.home_sections')->with($pageInfo);
	}
		
	 /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Home_sections  $Home_sections
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
		$services_details = Home_sections::find($id);
		$pageInfo = [
			'page_title' => 'Edit Home Sections',
			'menuId' => 'Sections',
			'services_details' => $services_details
		];
        return view('Admin.home_sections_edit')->with($pageInfo);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Home_sections  $Home_sections
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        request()->validate([
            'section_name' => 'required',	
            'description' => 'required',
            'title' => 'required'	
        ]);

		$details = Home_sections::find($id);
				
		$details->section_name = $request->post('section_name');
		$details->title = $request->post('title');
		$details->description = $request->post('description');
		$details->save();

        return redirect()->route('sections.index')
                        ->with('success', 'Details are updated successfully');
    }	
}
