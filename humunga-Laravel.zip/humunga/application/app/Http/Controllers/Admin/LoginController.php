<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class LoginController extends Controller
{
    public function index()
	{
		$pageInfo = [
			'page_title'=>'Login',
			'menuId' => 'Login'
		];
        return view('Admin/login')->with($pageInfo);
	}
}
