<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class TourController extends Controller
{		
    public function index()
	{
		$pageInfo = [
			'page_title'=>'Humunga | Tour',
			'Active_menu'=>'Tour'
		];
        return view('Frontend.tour')->with($pageInfo);
	}
}
