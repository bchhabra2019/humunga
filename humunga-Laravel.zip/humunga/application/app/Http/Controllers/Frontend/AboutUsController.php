<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class AboutUsController extends Controller
{		
    public function index()
	{
		$pageInfo = [
			'page_title'=>'Humunga | About us',
			'Active_menu'=>'About_us'
		];
        return view('Frontend.about_us')->with($pageInfo);
	}
}
