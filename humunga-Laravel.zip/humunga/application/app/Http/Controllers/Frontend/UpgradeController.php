<?php

namespace App\Http\Controllers\Frontend;

use DB;
use App\Subscription;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class UpgradeController extends Controller
{		
    public function index()
	{
		$subscription_details = DB::table('subscriptions')->orderBy('id', 'desc')->get();		
		$pageInfo = [
			'page_title' => 'Humunga | Upgrade',
			'Active_menu' => 'Upgrade',
			'subscription_details' => $subscription_details
		];
        return view('Frontend.upgrade')->with($pageInfo);
	}
}
