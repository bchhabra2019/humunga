<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ExampleController extends Controller
{		
    public function index()
	{
		$pageInfo = [
			'page_title'=>'Humunga | Example',
			'Active_menu'=>'Example'
		];
        return view('Frontend.example')->with($pageInfo);
	}
}
