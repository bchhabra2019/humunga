<?php

namespace App\Http\Controllers\Frontend;

use DB;
use Mail;
use App\Members;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Session;

class SignupController extends Controller
{		
    public function index()
	{
		if(Session::get('ID'))
		{		
			return redirect()->route('album.index');
		}
		$pageInfo = [
			'page_title'=>'Humunga | Sign Up',
			'Active_menu'=>''
		];
        return view('Frontend.signup')->with($pageInfo);
	}
	
	public function pro(Request $request)
	{	
		request()->validate([
            'email' => 'required|email|unique:members,email',
			'password' => 'required|confirmed|min:6',
			'password_confirmation'=>'',
        ]);
		$user_email = $request->input('email');
		
		$Email_arr = explode('@',$user_email);
		$Email_str = $Email_arr[0];
		$User_name = preg_replace('/[^A-Za-z0-9\-]/', '', $Email_str);
		
		$data['name'] = $User_name;
		$data['email'] = $request->input('email');
		$password = $request->input('password');
		$data['referral_code'] = sha1($User_name.''.$request->input('email').''.time());
		$data['password'] = sha1($password);
		
        Members::create($data);	
		/*
		$datas = array(
			'heading' => "Registration successfully!",
			'subject' => "Registration successful on Humunga",
			'name' => $data["name"],
			'Email' => $data["email"],
			'Password' => $password
		);

		Mail::send('Admin.email', $datas, function ($message) use ($datas) {

			$message->from('info@humunga.com', 'Humunga');

			$message->to($datas['Email'], $datas['name'])->subject('Registration successful on Humunga');

		});
		*/
		$notification = array(
			'message' => 'Signup successfully',
			'alert-type' => 'success'
		);
        return redirect()->route('signin.index')
                        ->with($notification);
	}
	
	/*
	* ------------------------------
	*	@ Ajax search form
	* --------------------------------------------------
	*/
	public function check_email(Request $request)
	{
		$userEmail = $request->get('email');
		$user_details = DB::table('members')->where('email',$userEmail)->get();
		
		if($user_details[0]->email)
		{
			echo 'ok';
			exit();
		}
		else
		{
			echo '';
			exit();
		}			
	}
}
