<?php

namespace App\Http\Controllers\Frontend;

use DB;
use App\Home_sections;
use App\Services;
use App\Slider;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class HomeController extends Controller
{		
    public function index()
	{
		$home_resut = Home_sections::all();
		$services_resut = Services::all();
		$slider_resut = Slider::all();
		$pageInfo = [
			'page_title'=>'Humunga | Home',
			'Active_menu'=>'Home',
			'home_resut' => $home_resut,
			'services_resut' => $services_resut,
			'slider_resut' => $slider_resut
		];
        return view('Frontend.home')->with($pageInfo);
	}
}
