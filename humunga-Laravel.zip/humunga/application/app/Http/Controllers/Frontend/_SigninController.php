<?php

namespace App\Http\Controllers\Frontend;

use DB;
use Mail;
use App\Members;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Session;

class SigninController extends Controller
{		
	public function __construct()
    {
				
    }

    public function index()
	{
		if(Session::get('ID'))
		{		
			return redirect()->route('album.index');
		}	
		$pageInfo = [
			'page_title'=>'Humunga | Signin',
			'Active_menu'=>'Tour'
		];
        return view('Frontend.signin')->with($pageInfo);
	}
	
	public function dologin(Request $request)
	{		
		request()->validate([
			'email' => 'required|email',
			'password' => 'required'
		]);		
		
		$email = $request->post('email');
		$password = $request->post('password');
		$dec_password = sha1($password);
		$user = DB::table('members')->where('email', $email)->where('password', $dec_password)->first();
		if($user)
		{
			$request->session()->put('ID', $user->id);
			$request->session()->put('uname', $user->name);
			$notification = array(
				'message' => 'Success! Logged In',
				'alert-type' => 'success'
			);
			return redirect()->route('album.index')->with($notification);
		}
		else
		{
			//flashy()->error('User details are not found');
			$notification = array(
				'message' => 'User details are not found',
				'alert-type' => 'error'
			);
			return redirect()->route('signin.index')->with($notification);
		}
	}
	
	public function forgotpw()
	{
		$pageInfo = [
			'page_title'=>'Humunga | Forgot Password',
			'Active_menu'=>''
		];
        return view('Frontend.forgotpw')->with($pageInfo);
	}
	
	public function forgotpwpro(Request $request)
	{		
		request()->validate([
			'email' => 'required|email'
		]);		
		
		$uemail = $request->post('email');
		
		$user = DB::table('members')->where('email', $uemail)->first();
		if($user)
		{




		$subject = 'Forgot Password';	
		$email = $user->email;	

		//$message = "/signin.resetpw/".time();
		$datas = array(
			'heading' => "Forgot Password!",
			'subject' => "Forgot Password",
			'name' => $user->name,
			'email' => $user->email,
			'resetPassLink' => "/signin.resetpw/".time()
		);
		$message = view('Frontend.forgotpw_temp')->with($datas);
		
		$url = 'https://api.sendgrid.com/';
		$user = 'basant0906';
		$pass = 'Immersive@123';
 		$params = array(
			'api_user'  => $user,
			'api_key'   => $pass,
	 		'to'        => $email,
			'subject'   => $subject,
			'html'      => $message,
		 	'from'      => 'support@humunga.com',
		  );
		$request =  $url.'api/mail.send.json';
		// Generate curl request
		$session = curl_init($request);
		// Tell curl to use HTTP POST
		curl_setopt ($session, CURLOPT_POST, true);
		// Tell curl that this is the body of the POST
		curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
		// Tell curl not to return headers, but do return the response
		curl_setopt($session, CURLOPT_HEADER, false);
		// Tell PHP not to use SSLv3 (instead opting for TLS)
		curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
		curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

		// obtain response
		$response = curl_exec($session);
		//var_dump($response);
		curl_close($session);
 		// print everything out
		// return $response;         

			
			/*$datas = array(
				'heading' => "Forgot Password!",
				'subject' => "Forgot Password",
				'name' => $user->name,
				'email' => $user->email,
				'resetPassLink' => "/signin.resetpw/".time()
			);*/

/*			Mail::send('Frontend.forgotpw_temp', $datas, function ($message) use ($datas) {

				$message->from('humunga@redmapple.com', 'Humunga');

				$message->to($datas['email'], $datas['name'])->subject('Forgot Password');

			});
			
*/			$notification = array(
				'message' => 'Send a link on your email, for reset password',
				'alert-type' => 'success'
			);
			return redirect()->route('signin.forgotpw')->with($notification);
		}
		else
		{
			$notification = array(
				'message' => 'Error! User details are not found',
				'alert-type' => 'error'
			);
			return redirect()->route('signin.forgotpw')->with($notification);
		}
	}
	
	public function logout(Request $request)
	{
		$request->session()->put('ID', '');
		$request->session()->put('uname', '');
		Session::flush();
		$notification = array(
			'message' => 'Success! Logged out',
			'alert-type' => 'success'
		);
		return redirect()->route('signin.index')->with($notification);
	}
}
