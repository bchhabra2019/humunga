<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Session;

class AlbumController extends Controller
{		
    public function index()
	{	
		if(Session::get('ID') == null)
		{		
			$notification = array(
				'message' => 'Error! Login first',
				'alert-type' => 'error'
			);
			
			return redirect()->route('signin.index')->with($notification);
		}
		else		
		{
			$pageInfo = [
				'page_title'=>'Humunga | Album',
				'Active_menu'=>'Album'
			];
			return view('Frontend.album')->with($pageInfo);			
		}
	}
}
