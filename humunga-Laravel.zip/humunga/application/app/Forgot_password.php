<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Forgot_password extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_id', 'token', 'expiry_time'
    ];
}