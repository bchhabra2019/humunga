<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Members extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password', 'referral_code', 'plan_id', 'referenced_code', 'image', 'business', 'website', 'biography', 'phone', 'country', 'facebook', 'instagram', 'yt_link', 'vimeo', 'linkedin'
    ];
}