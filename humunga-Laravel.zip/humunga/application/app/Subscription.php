<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Subscription extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'heading', 'description', 'price', 'duration', 'data_space', 'offer_duration1', 'offer_duration2', 'offer_duration3', 'offer_percent1', 'offer_percent2', 'offer_percent3', 'offer_expiry1', 'offer_expiry2', 'offer_expiry3'
    ];
}