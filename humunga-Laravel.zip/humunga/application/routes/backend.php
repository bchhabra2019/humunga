<?php

Route::get('/dashboard', 'AdminController@index');

Route::get('/subscription', 'SubscriptionController@index');

Route::get('/members', 'MembersController@index');

Route::get('/slider', 'SliderController@index');

Route::get('/services', 'ServicesController@index');

Route::get('/sections', 'HomeSectionController@index');

Route::get('/members/search_ajax', 'MembersController@search_ajax');

Route::resource('/subscription', 'SubscriptionController');

Route::resource('/members', 'MembersController');

Route::resource('/systememail', 'SystememailController');

Route::resource('/systempages', 'SystempagesController');

Route::resource('/websitesetting', 'WebsiteSettingController');

Route::resource('/slider', 'SliderController');

Route::resource('/services', 'ServicesController');

Route::resource('/sections', 'HomeSectionController');

Route::get('/login', 'LoginController@index');