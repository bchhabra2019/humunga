<?php

Route::get('/', 'HomeController@index');

Route::get('/home', 'HomeController@index');

//Route::get('/signin', 'SigninController@index');

Route::get('/signin', [
	'uses' => 'SigninController@index',
	'as' => 'signin.index'
]);

Route::post('/signin/dologin', [
	'uses' => 'SigninController@dologin',
	'as' => 'signin.dologin'
]);

Route::get('/forgotpw', [
	'uses' => 'SigninController@forgotpw',
	'as' => 'signin.forgotpw'
]);

Route::get('/logout', [
	'uses' => 'SigninController@logout',
	'as' => 'signin.logout'
]);

Route::post('/signin/forgotpwpro', [
	'uses' => 'SigninController@forgotpwpro',
	'as' => 'signin.forgotpwpro'
]);

Route::get('/resetpw/{id}', [
	'uses' => 'SigninController@resetpw',
	'as' => 'signin.resetpw'
]);

Route::post('/signin/resetpwpro', [
	'uses' => 'SigninController@resetpwpro',
	'as' => 'signin.resetpwpro'
]);

Route::get('/signup', 'SignupController@index');

Route::post('/signup/pro', [
	'uses' => 'SignupController@pro',
	'as' => 'signup.pro'
]);

Route::get('/signup/check_email', 'SignupController@check_email');

Route::get('/tour', 'TourController@index');

Route::get('/about-us', 'AboutUsController@index');

Route::get('/upgrade', 'UpgradeController@index');

Route::get('/example', 'ExampleController@index');

//Route::get('/album', 'AlbumController@index');

Route::get('/album', [
	'uses' => 'AlbumController@index',
	'as' => 'album.index'
]);