<!DOCTYPE html>
<html lang="en">    
	<head>
        <meta charset="utf-8" />
        <title>{{ $page_title or "Dashboard" }}</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="active-menu" content="{{ $menuId }}">
        <!-- App favicon -->
        <link rel="shortcut icon" href="{{ asset('/admin/images/favicon.ico') }}">

        <!--Morris Chart-->
        <link rel="stylesheet" href="{{ asset('/admin/libs/morris-js/morris.css') }}" />

        <!-- App css -->
        <link href="{{ asset('/admin/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" />		        <link href="{{ asset('/admin/libs/datatables/dataTables.bootstrap4.css') }}" rel="stylesheet" type="text/css" />        <link href="{{ asset('/admin/libs/datatables/responsive.bootstrap4.css') }}" rel="stylesheet" type="text/css" />        <link href="{{ asset('/admin/libs/datatables/buttons.bootstrap4.css') }}" rel="stylesheet" type="text/css" />        <link href="{{ asset('/admin/libs/datatables/select.bootstrap4.css') }}" rel="stylesheet" type="text/css" />
        <link href="{{ asset('/admin/css/icons.min.css') }}" rel="stylesheet" type="text/css" />
        <link href="{{ asset('/admin/css/custom.css') }}" rel="stylesheet" type="text/css" />
        <link href="{{ asset('/admin/css/app.min.css') }}" rel="stylesheet" type="text/css" />
		<link href = "https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css" rel = "stylesheet">
		<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
		<script src = "https://code.jquery.com/jquery-1.10.2.js"></script>
		<script src = "https://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
		<script src="https://cdn.ckeditor.com/4.11.4/standard/ckeditor.js"></script>
		<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
		<link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">
    </head>

    <body>

        <!-- Begin page -->
        <div id="wrapper">

            @include('Admin.header')

            <!-- ========== Left Sidebar Start ========== -->
            @include('Admin.sidebar')
            <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">

                    <!-- Dynamic containt -->
					@yield('content')
                    <!--// -->
					
                </div> <!-- content -->

                <!-- Footer Start -->
                @include('Admin.footer')
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->

        <!-- Vendor js -->
        <script src="{{ asset('/admin/js/vendor.min.js') }}"></script>		        <script src="{{ asset('/admin/libs/datatables/jquery.dataTables.min.js') }}"></script>        <script src="{{ asset('/admin/libs/datatables/dataTables.bootstrap4.js') }}"></script>        <script src="{{ asset('/admin/libs/datatables/dataTables.responsive.min.js') }}"></script>        <script src="{{ asset('/admin/libs/datatables/responsive.bootstrap4.min.js') }}"></script>        <script src="{{ asset('/admin/libs/datatables/dataTables.buttons.min.js') }}"></script>        <script src="{{ asset('/admin/libs/datatables/buttons.bootstrap4.min.js') }}"></script>        <script src="{{ asset('/admin/libs/datatables/buttons.html5.min.js') }}"></script>        <script src="{{ asset('/admin/libs/datatables/buttons.flash.min.js') }}"></script>        <script src="{{ asset('/admin/libs/datatables/buttons.print.min.js') }}"></script>        <script src="{{ asset('/admin/libs/datatables/dataTables.keyTable.min.js') }}"></script>        <script src="{{ asset('/admin/libs/datatables/dataTables.select.min.js') }}"></script>		        <script src="{{ asset('/admin/js/pages/datatables.init.js') }}"></script>
        <!-- knob plugin -->
        <script src="{{ asset('/admin/libs/jquery-knob/jquery.knob.min.js') }}"></script>
        <!--Morris Chart-->
        <script src="{{ asset('/admin/libs/morris-js/morris.min.js') }}"></script>
        <script src="{{ asset('/admin/libs/raphael/raphael.min.js') }}"></script>

        <!-- Dashboard init js-->
        <script src="{{ asset('/admin/js/pages/dashboard.init.js') }}"></script>

        <!-- App js -->
        <script src="{{ asset('/admin/js/app.min.js') }}"></script>
        <script src="{{ asset('/admin/js/common.js') }}"></script>
        <script src="https://cdn.ckeditor.com/4.11.4/standard/ckeditor.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/4.4.0/bootbox.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
		<script>
			$(function() {
				$(".datepicker").datepicker({ 
					autoclose: true, 
					startDate: '+2d',
					formate: 'dd-mm-yy'
				});
			});
			
			/* Check email */
			function checkEmail()
			{
				$("#user_email_validation").html("");		
				var emails = $("#user_email").val();
				var dataString = "email="+emails;
				$.ajax({
					url : "./search_ajax",
					type : "GET",
					data : dataString,
					success : function(response)
					{
						if(response == 'ok')
						{
							$("#user_email_validation").html("This email is already exist");
						}
						else
						{
							$("#user_email_validation").html("");							
						}
					}
				});
			}
			
			/* Set status */
			function setStatus(ID, status)
			{ 
				var dataString = "id="+ID+"&status="+status;
				$.ajax({
					url : "{{url('admin/subscription/set_status')}}",  
					type : "POST",
					data : dataString,
					success : function(response)
					{
						
					}
				});
			}
			
		</script>
    </body>

</html>