@extends('Admin.admin_template')

@section('content')
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 margin-tb">
				<div class="pull-left">
					<h3> Show Member</h3>
				</div>
				<div class="pull-right add-btn">
					<a class="btn btn-primary" href="{{ route('members.index') }}"> Back</a>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-6 col-sm-6 col-md-6">
				<div class="form-group">
					<label>Name:</label>
					<p>{{ $member->name }}</p>
				</div>
			</div>
			<div class="col-xs-6 col-sm-6 col-md-6">
				<div class="form-group">
					<label>Email:</label>
					<p>{{ $member->email }}</p>
				</div>
			</div>
			<div class="col-xs-6 col-sm-6 col-md-6">
				<div class="form-group">
					<label>Plan:</label>
					<p>{{ @$plan_details->plan_name }}</p>
				</div>
			</div>
		</div>
	</div>

@endsection