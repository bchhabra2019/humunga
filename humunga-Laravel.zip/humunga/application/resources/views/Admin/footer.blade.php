	<footer class="footer">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-6">
				   2019 &copy; Laravel <a href="#">BRinfotech</a> 
				</div>
			</div>
		</div>
	</footer>