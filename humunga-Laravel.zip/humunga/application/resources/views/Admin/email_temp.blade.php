<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h3>{!! $heading !!} </h3>
		<div>
			<p><strong>Dear {!! $name !!}</strong>,</p>
			<p>Welcome to Humunga!</p>
			<p>Login details: 	</p>
			<p>Username: <b>{!! $Email !!}</b></p>
			<p>Password: <b>{!! $Password !!}</b></p>						
			<p>URL : <a href="{{ url('/') }}">{{  url('/')}}</a></p>
			<p>Humunga team</p>
		</div>
	</body>
</html>