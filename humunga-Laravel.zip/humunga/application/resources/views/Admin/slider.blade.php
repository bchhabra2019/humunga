@extends('Admin.admin_template')

@section('content')
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 margin-tb">
				<div class="pull-left">
					<h3>Slider</h3>
				</div>
				<div class="pull-right add-btn">
					<a class="btn btn-success" href="{{ route('slider.create') }}" title="Slider"> Create New</a>
				</div>
			</div>
		</div>
		@if ($message = Session::get('success'))
			<div class="alert alert-success">
				<p>{{ $message }}</p>
			</div>
		@endif
		<table class="table table-bordered">
			<tr>
				<th>Icon</th>
				<th>Image</th>
				<th>Type</th>
				<th>Status</th>
				<th width="10%">Action</th>
			</tr>
			@if($slider_resut)
				@foreach ($slider_resut as $res)
				<tr>
					<td>
						<img src="{{ url('application/public/admin/images/'.$res->icon) }}" alt="{{ $res->icon }}" width="100px" height="100px">
					</td>
					<td>
						<img src="{{ url('application/public/admin/images/'.$res->image) }}" alt="{{ $res->icon }}" width="100px" height="100px">
					</td>
					<td>{{ $res->type }}</td>
					<td>
						@if($res->status == 0)
							Inactive
						@else
							Active
						@endif
					</td>
					<td >
						<form action="{{ route('slider.destroy',$res->id) }}" method="POST">						
							<a href="{{ route('slider.edit',$res->id) }}"><i class="fa fa-edit fa-2x text-info" title="Edit"></i></a>
							@csrf
							@method('DELETE')		   
							<button type="submit" class="form-icon"><i class="fa fa-trash fa-2x text-danger" title="Delete"></i></button>
						</form>
					</td>
				</tr>
				@endforeach
			@else
				<tr>
					<td colspan="3">No recode found</td>
				</tr>
			@endif
		</table>	   
	</div> <!-- container -->
@endsection