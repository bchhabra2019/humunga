@extends('Admin.admin_template')

@section('content')
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 margin-tb">
				<div class="pull-left">
					<h3>Add New Members</h3>
				</div>
				<div class="pull-right add-btn">
					<a class="btn btn-primary" href="{{ route('members.index') }}"> Back</a>
				</div>
			</div>
		</div>

		@if ($errors->any())
			<div class="alert alert-danger">
				<strong>Whoops!</strong> There were some problems with your input.<br><br>
				<ul>
					@foreach ($errors->all() as $error)
						<li>{{ $error }}</li>
					@endforeach
				</ul>
			</div>
		@endif

		<form action="{{ route('members.store') }}" method="POST">
			@csrf
			<div class="row">
				<div class="col-xs-3 col-sm-3 col-md-3">
					<div class="form-group">
						<strong>Image</strong>
						<input type="file" name="image" />
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-4 col-sm-4 col-md-4">
					<div class="form-group">
						<strong>Name<span class="text-danger">*</span></strong>
						<input name="_token" type="hidden" id="_token" value="{{ csrf_token() }}" />
						<input type="text" name="name" class="form-control" placeholder="Name">
					</div>
				</div>			
				<div class="col-xs-4 col-sm-4 col-md-4">
					<div class="form-group">
						<strong>Email<span class="text-danger">*</span></strong>
						<input type="email" name="email" id="user_email" onBlur="checkEmail()" class="form-control" placeholder="Email">
						<div id="user_email_validation" class="text-danger"></div>
					</div>
				</div>
				<div class="col-xs-4 col-sm-4 col-md-4">
					<div class="form-group">
						<strong>Contect number</strong>
						<input type="number" name="phone" id="user_phone" class="form-control" placeholder="Phone">
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-4 col-sm-4 col-md-4">
					<div class="form-group">
						<strong>Countrt</strong>
						<input type="text" name="country" id="user_country" class="form-control" placeholder="Country">
					</div>
				</div>
				<div class="col-xs-4 col-sm-4 col-md-4">
					<div class="form-group">
						<strong>Business</strong>
						<input type="text" name="business" id="user_business" class="form-control" placeholder="Business">
					</div>
				</div>
				<div class="col-xs-4 col-sm-4 col-md-4">
					<div class="form-group">
						<strong>Websilte</strong>
						<input type="url" name="website" id="user_website" class="form-control" placeholder="Website">
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-8 col-sm-8 col-md-8">
					<div class="form-group">
						<strong>Biography</strong>
						<textarea name="biography" class="form-control"></textarea>
					</div>
				</div>
				<div class="col-xs-4 col-sm-4 col-md-4">
					<div class="form-group">
						<strong>Facebook link</strong>
						<input type="url" name="facebook" id="user_facebook" class="form-control" placeholder="Facebook link">
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-4 col-sm-4 col-md-4">
					<div class="form-group">
						<strong>Instagram link</strong>
						<input type="url" name="instagram" id="user_instagram" class="form-control" placeholder="Instagram link">
					</div>
				</div>
				<div class="col-xs-4 col-sm-4 col-md-4">
					<div class="form-group">
						<strong>YT link</strong>
						<input type="url" name="yt_link" id="user_yt_link" class="form-control" placeholder="YT link">
					</div>
				</div>
				<div class="col-xs-4 col-sm-4 col-md-4">
					<div class="form-group">
						<strong>Vimeo link</strong>
						<input type="url" name="vimeo" id="user_vimeo" class="form-control" placeholder="Vimeo link">
					</div>
				</div>
				<div class="col-xs-4 col-sm-4 col-md-4">
					<div class="form-group">
						<strong>Linkedin link</strong>
						<input type="url" name="linkedin" id="user_linkedin" class="form-control" placeholder="Linkedin link">
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<button type="submit" class="btn btn-success">Submit</button>
				</div>
			</div>
		</form>
	</div>
@endsection