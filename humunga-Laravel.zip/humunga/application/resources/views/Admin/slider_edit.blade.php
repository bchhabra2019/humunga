@extends('Admin.admin_template')

@section('content')
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 margin-tb">
				<div class="pull-left">
					<h3>Slider</h3>
				</div>
				<div class="pull-right add-btn">
					<a class="btn btn-primary" href="{{ route('slider.index') }}"> Back</a>
				</div>
			</div>
		</div>

		@if ($errors->any())
			<div class="alert alert-danger">
				<strong>Whoops!</strong> There were some problems with your input.<br><br>
				<ul>
					@foreach ($errors->all() as $error)
						<li>{{ $error }}</li>
					@endforeach
				</ul>
			</div>
		@endif

		<form action="{{ route('slider.update',$slider_details->id) }}" method="POST" enctype="multipart/form-data">
			@csrf
			@method('PUT')

			 <div class="row">
				<div class="col-xs-3 col-sm-3 col-md-3">
					<div class="form-group">
						<strong>Icon</strong>
						<img src="{{ url('application/public/admin/images/'.$slider_details->icon) }}" alt="{{ $slider_details->icon }}" width="100" height="100">
					</div>
				</div>
				<div class="col-xs-3 col-sm-3 col-md-3">
					<div class="form-group">
						<strong>Change</strong>
						<input type="file" name="icon" />
					</div>
				</div>
				<div class="col-xs-3 col-sm-3 col-md-3">
					<div class="form-group">
						<strong>Image</strong>
						<img src="{{ url('application/public/admin/images/'.$slider_details->image) }}" alt="{{ $slider_details->image }}" width="100" height="100">
					</div>
				</div>
				<div class="col-xs-3 col-sm-3 col-md-3">
					<div class="form-group">
						<strong>Change</strong>
						<input type="file" name="image" />
					</div>
				</div>
				<div class="col-xs-3 col-sm-3 col-md-3">
					<div class="form-group">
						<strong>Type<sup class="text-danger">*</sup></strong>
						<select name="type" class="form-control">
							<option value="Home" {{ ($slider_details->type == 'Home') ? 'selected' : '' }}> Home </option>
							<option value="Mini" {{ ($slider_details->type == 'Mini') ? 'selected' : '' }}> Mini </option>
						</select>
					</div>
				</div>
				<div class="col-xs-3 col-sm-3 col-md-3">
					<div class="form-group">
						<strong>Status<sup class="text-danger">*</sup></strong>
						<select name="status" class="form-control">
							<option value="1" {{ ($slider_details->status == '1') ? 'selected' : '' }}> Active </option>
							<option value="0" {{ ($slider_details->status == '0') ? 'selected' : '' }}> Inactive </option>
						</select>
					</div>
				</div>
				<div class="col-xs-6 col-sm-6 col-md-6">
					<div class="form-group">
						<strong>Title</strong>
						<textarea name="title" class="form-control">{{ $slider_details->title }}</textarea>
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Description</strong>
						<textarea name="description" class="form-control">{{ $slider_details->description }}</textarea>
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
				  <button type="submit" class="btn btn-success">Update</button>
				</div>
			</div>
		</form>
	</div>
@endsection