@extends('Admin.admin_template')

@section('content')
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 margin-tb">
				<div class="pull-left">
					<h3>Services</h3>
				</div>
			</div>
		</div>
		@if ($message = Session::get('success'))
			<div class="alert alert-success">
				<p>{{ $message }}</p>
			</div>
		@endif
		<table class="table table-bordered">
			<tr>
				<th>Icon</th>
				<th>Name</th>
				<th>Description</th>
				<th width="10%">Action</th>
			</tr>
			@if($services_resut)
				@foreach ($services_resut as $res)
				<tr>
					<td><img src="{{ url('application/public/admin/images/'.$res->icon) }}" width="100px" height="100px"></td>
					
					<td>{{ $res->name }}</td>
					
					<td>{{ $res->description }}</td>
					<td >
						<a href="{{ route('services.edit',$res->id) }}"><i class="fa fa-edit fa-2x text-info" title="Edit"></i></a>						
					</td>
				</tr>
				@endforeach
			@else
				<tr>
					<td colspan="3">No recode found</td>
				</tr>
			@endif
		</table>	   
	</div> <!-- container -->
@endsection