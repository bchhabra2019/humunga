@extends('Admin.admin_template')

@section('content')
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 margin-tb">
				<div class="pull-left">
					<h3> Show {{ $systememails->name }} System Email</h3>
				</div>
				<div class="pull-right">
					<a class="btn btn-primary" href="{{ route('systememail.index') }}"> Back</a>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-xs-6 col-sm-6 col-md-6">
				<div class="form-group">
					<label>Title:</label>
					<p>{{ $systememails->title }}</p>
				</div>
			</div>
			<div class="col-xs-6 col-sm-6 col-md-6">
				<div class="form-group">
					<label>Subject:</label>
					<p>{{ $systememails->subject }}</p>
				</div>
			</div>
			<div class="col-xs-12 col-sm-12 col-md-12">
				<div class="form-group">
					<label>Message:</label>
					<p>{{ strip_tags($systememails->message) }}</p>
				</div>
			</div>
		</div>
	</div>

@endsection