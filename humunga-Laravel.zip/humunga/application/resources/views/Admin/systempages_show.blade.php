@extends('Admin.admin_template')

@section('content')
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 margin-tb">
				<div class="pull-left">
					<h3> Show {{ $systempages_details->name }} </h3>
				</div>
				<div class="pull-right">
					<a class="btn btn-primary" href="{{ route('systempages.index') }}"> Back</a>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-xs-6 col-sm-6 col-md-6">
				<div class="form-group">
					<label>Name:</label>
					<p>{{ $systempages_details->name }}</p>
				</div>
			</div>
			<div class="col-xs-6 col-sm-6 col-md-6">
				<div class="form-group">
					<label>Heading:</label>
					<p>{{ $systempages_details->heading }}</p>
				</div>
			</div>
			<div class="col-xs-12 col-sm-12 col-md-12">
				<div class="form-group">
					<label>Description:</label>
					<p>{{ strip_tags($systempages_details->description) }}</p>
				</div>
			</div>
		</div>
	</div>

@endsection