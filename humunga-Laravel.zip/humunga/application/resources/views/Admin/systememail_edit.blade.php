@extends('Admin.admin_template')

@section('content')
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 margin-tb">
				<div class="pull-left">
					<h2>Edit System Email</h2>
				</div>
				<div class="pull-right">
					<a class="btn btn-primary" href="{{ route('systememail.index') }}"> Back</a>
				</div>
			</div>
		</div>

		@if ($errors->any())
			<div class="alert alert-danger">
				<strong>Whoops!</strong> There were some problems with your input.<br><br>
				<ul>
					@foreach ($errors->all() as $error)
						<li>{{ $error }}</li>
					@endforeach
				</ul>
			</div>
		@endif

		<form action="{{ route('systememail.update',$system_details->id) }}" method="POST">
			@csrf
			@method('PUT')

			 <div class="row">
				<div class="col-xs-6 col-sm-6 col-md-6">
					<div class="form-group">
						<strong>Title<sup class="text-danger">*</sup></strong>
						<input type="text" name="title" value="{{ $system_details->title }}" class="form-control" placeholder="Title">
					</div>
				</div>
				<div class="col-xs-6 col-sm-6 col-md-6">
					<div class="form-group">
						<strong>Subject<sup class="text-danger">*</sup></strong>
						<input type="text" name="subject" value="{{ $system_details->subject }}" class="form-control" placeholder="Subject">
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Message<sup class="text-danger">*</sup></strong>
						<textarea class="form-control" style="height:150px" name="message">{{ $system_details->message }}</textarea>
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
				  <button type="submit" class="btn btn-success">Submit</button>
				</div>
			</div>
		</form>
	</div>
	<script>
		CKEDITOR.replace( 'message' );
	</script>
@endsection