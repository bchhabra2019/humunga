@extends('Admin.admin_template')

@section('content')
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 margin-tb">
				<div class="pull-left">
					<h2>Edit Subscription</h2>
				</div>
				<div class="pull-right">
					<a class="btn btn-primary" href="{{ route('subscription.index') }}"> Back</a>
				</div>
			</div>
		</div>

		@if ($errors->any())
			<div class="alert alert-danger">
				<strong>Whoops!</strong> There were some problems with your input.<br><br>
				<ul>
					@foreach ($errors->all() as $error)
						<li>{{ $error }}</li>
					@endforeach
				</ul>
			</div>
		@endif

		<form action="{{ route('subscription.update',$subscription->id) }}" method="POST">
			@csrf
			@method('PUT')

			 <div class="row">
				<div class="col-xs-6 col-sm-6 col-md-6">
					<div class="form-group">
						<strong>Name<sup class="text-danger">*</sup></strong>
						<input type="text" name="name" value="{{ $subscription->name }}" class="form-control" placeholder="Name">
					</div>
				</div>
				<div class="col-xs-6 col-sm-6 col-md-6">
					<div class="form-group">
						<strong>Price<sup class="text-danger">*</sup></strong>
						<input type="text" name="price" value="{{ $subscription->price }}" class="form-control" placeholder="Price">
					</div>
				</div>
				<div class="col-xs-6 col-sm-6 col-md-6">
					<div class="form-group">
						<strong>Duration<sup class="text-danger">*</sup></strong>
						<select name="duration" class="form-control">
							<option value="30" {{ (@$subscription->duration == '30') ? 'selected':'' }}> 1 Month </option>							
						</select>
					</div>
				</div>
				<div class="col-xs-6 col-sm-6 col-md-6">
					<div class="form-group">
						<strong>Space<sup class="text-danger">*</sup></strong>
						<select name="data_space" class="form-control">
							<option value="">--- Select Space ---</option>
							<option value="1" {{ (@$subscription->data_space == '1') ? 'selected':'' }}> 1 GB </option>
							<option value="3" {{ (@$subscription->data_space == '3') ? 'selected':'' }}> 3 GB </option>
							<option value="6" {{ (@$subscription->data_space == '6') ? 'selected':'' }}> 6 GB </option>
							<option value="12" {{ @$subscription->data_space == '12' ? 'selected':'' }}> 12 GB </option>
						</select>
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Heading<sup class="text-danger">*</sup></strong>
						<textarea class="form-control" style="height:50px" name="heading">{{ $subscription->heading }}</textarea>
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Description<sup class="text-danger">*</sup></strong>
						<textarea class="form-control" style="height:150px" name="description">{{ $subscription->description }}</textarea>
					</div>
				</div>
				<div class="col-xs-3 col-sm-3 col-md-3">
					<div class="form-group">
						<label>Offer duration</label>
					</div>
				</div>
				<div class="col-xs-3 col-sm-3 col-md-3">
					<div class="form-group">
						<label>Offer percentage</label>
					</div>
				</div>
				<div class="col-xs-3 col-sm-3 col-md-3">
					<div class="form-group">
						<label>Offer Expire</label>
					</div>
				</div>
			</div>
			<div class="show_offer">
				<div class="row">
					<div class="col-xs-3 col-sm-3 col-md-3">
						<div class="form-group">
							<select name="offer_duration1" class="form-control">
								<option value="3" {{ (@$subscription->offer_duration1 == '3') ? 'selected':'' }}> 3 Month </option>
							</select>
						</div>
					</div>
					<div class="col-xs-3 col-sm-3 col-md-3">
						<div class="form-group">
							<input type="text" class="form-control" value="{{ $subscription->offer_percent1 }}" name="offer_percent1">
						</div>
					</div>	
					<div class="col-xs-3 col-sm-3 col-md-3">
						<div class="form-group">
							<input type="text" data-date-format="dd-mm-yyyy" class="form-control datepicker" value="{{ $subscription->offer_expiry1 }}" name="offer_expiry1">
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-xs-3 col-sm-3 col-md-3">
						<div class="form-group">
							<select name="offer_duration2" class="form-control">
								<option value="6" {{ (@$subscription->offer_duration2 == '6') ? 'selected':'' }}> 6 Month </option>
							</select>
						</div>
					</div>
					<div class="col-xs-3 col-sm-3 col-md-3">
						<div class="form-group">
							<input type="text" class="form-control" value="{{ $subscription->offer_percent2 }}" name="offer_percent2">
						</div>
					</div>	
					<div class="col-xs-3 col-sm-3 col-md-3">
						<div class="form-group">
							<input type="text" data-date-format="dd-mm-yyyy" class="form-control datepicker" value="{{ $subscription->offer_expiry2 }}" name="offer_expiry2">
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-xs-3 col-sm-3 col-md-3">
						<div class="form-group">
							<select name="offer_duration3" class="form-control">
								<option value="12" {{ (@$subscription->offer_duration3 == '12') ? 'selected':'' }}> 1 Year </option>
							</select>
						</div>
					</div>
					<div class="col-xs-3 col-sm-3 col-md-3">
						<div class="form-group">
							<input type="text" class="form-control" value="{{ $subscription->offer_percent3 }}" name="offer_percent3">
						</div>
					</div>	
					<div class="col-xs-3 col-sm-3 col-md-3">
						<div class="form-group">
							<input type="text" data-date-format="dd-mm-yyyy" class="form-control datepicker" value="{{ $subscription->offer_expiry3 }}" name="offer_expiry3">
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
				  <button type="submit" class="btn btn-success">Update</button>
				</div>
			</div>
			</div>
		</form>
	</div>
	<script>
		CKEDITOR.replace( 'description' );
	</script>
@endsection