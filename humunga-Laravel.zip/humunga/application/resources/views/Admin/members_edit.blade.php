@extends('Admin.admin_template')

@section('content')
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 margin-tb">
				<div class="pull-left">
					<h3>Edit Member</h3>
				</div>
				<div class="pull-right add-btn">
					<a class="btn btn-primary" href="{{ route('members.index') }}"> Back</a>
				</div>
			</div>
		</div>

		@if ($errors->any())
			<div class="alert alert-danger">
				<strong>Whoops!</strong> There were some problems with your input.<br><br>
				<ul>
					@foreach ($errors->all() as $error)
						<li>{{ $error }}</li>
					@endforeach
				</ul>
			</div>
		@endif

		<form action="{{ route('members.update',$member->id) }}" method="POST">
			@csrf
			@method('PUT')
			
			<div class="row">
				<div class="col-xs-3 col-sm-3 col-md-3">
					<div class="form-group">
						<strong>Image</strong>
						<img src="{{ url('admin/images/'.$member->image) }}" alt="{{ $member->image }}"  width="100" height="100">
					</div>
				</div>
				<div class="col-xs-3 col-sm-3 col-md-3">
					<div class="form-group">
						<strong>Change</strong>
						<input type="file" name="image" />
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-4 col-sm-4 col-md-4">
					<div class="form-group">
						<strong>Name<sup class="text-danger">*</sup></strong>
						<input type="text" name="name" value="{{ $member->name }}" class="form-control">
					</div>
				</div>
				<div class="col-xs-4 col-sm-4 col-md-4">
					<div class="form-group">
						<strong>Email</strong>
						<input type="text" value="{{ $member->email }}" class="form-control" readonly />
					</div>
				</div>
				<div class="col-xs-4 col-sm-4 col-md-4">
					<div class="form-group">
						<strong>Contect number</strong>
						<input type="number" name="phone" value="{{ $member->phone }}" id="user_phone" class="form-control" placeholder="Phone">
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-4 col-sm-4 col-md-4">
					<div class="form-group">
						<strong>Countrt</strong>
						<input type="text" name="country" value="{{ $member->country }}" id="user_country" class="form-control" placeholder="Country">
					</div>
				</div>
				<div class="col-xs-4 col-sm-4 col-md-4">
					<div class="form-group">
						<strong>Business</strong>
						<input type="text" name="business" value="{{ $member->business }}" id="user_business" class="form-control" placeholder="Business">
					</div>
				</div>
				<div class="col-xs-4 col-sm-4 col-md-4">
					<div class="form-group">
						<strong>Websilte</strong>
						<input type="url" name="website" value="{{ $member->website }}" id="user_website" class="form-control" placeholder="Website">
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-8 col-sm-8 col-md-8">
					<div class="form-group">
						<strong>Biography</strong>
						<textarea name="biography" class="form-control">{{ $member->biography }}</textarea>
					</div>
				</div>
				<div class="col-xs-4 col-sm-4 col-md-4">
					<div class="form-group">
						<strong>Facebook link</strong>
						<input type="url" name="facebook" value="{{ $member->facebook }}" id="user_facebook" class="form-control" placeholder="Facebook link">
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-4 col-sm-4 col-md-4">
					<div class="form-group">
						<strong>Instagram link</strong>
						<input type="url" name="instagram" value="{{ $member->instagram }}" id="user_instagram" class="form-control" placeholder="Instagram link">
					</div>
				</div>
				<div class="col-xs-4 col-sm-4 col-md-4">
					<div class="form-group">
						<strong>YT link</strong>
						<input type="url" name="yt_link" value="{{ $member->yt_link }}" id="user_yt_link" class="form-control" placeholder="YT link">
					</div>
				</div>
				<div class="col-xs-4 col-sm-4 col-md-4">
					<div class="form-group">
						<strong>Vimeo link</strong>
						<input type="url" name="vimeo" value="{{ $member->vimeo }}" id="user_vimeo" class="form-control" placeholder="Vimeo link">
					</div>
				</div>
				<div class="col-xs-4 col-sm-4 col-md-4">
					<div class="form-group">
						<strong>Linkedin link</strong>
						<input type="url" name="linkedin" value="{{ $member->linkedin }}" id="user_linkedin" class="form-control" placeholder="Linkedin link">
					</div>
				</div>
				<div class="col-xs-8 col-sm-8 col-md-8 add-btn">
					<div class="form-group">
						<strong>&nbsp;</strong><br>
						<button type="submit" class="btn btn-success">Update</button>
					</div>
				</div>
			</div>
		</form>
	</div>
@endsection