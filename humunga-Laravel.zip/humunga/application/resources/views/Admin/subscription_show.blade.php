@extends('Admin.admin_template')

@section('content')
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 margin-tb">
				<div class="pull-left">
					<h2> Show Subscription</h2>
				</div>
				<div class="pull-right">
					<a class="btn btn-primary" href="{{ route('subscription.index') }}"> Back</a>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-xs-6 col-sm-6 col-md-6">
				<div class="form-group">
					<label>Name:</label>
					<p>{{ $subscription->name }}</p>
				</div>
			</div>
			<div class="col-xs-6 col-sm-6 col-md-6">
				<div class="form-group">
					<label>Price:</label>
					<p>{{ $subscription->price }}</p>
				</div>
			</div>
			<div class="col-xs-6 col-sm-6 col-md-6">
				<div class="form-group">
					<label>Duration:</label>
					<p>{{ $subscription->duration }}</p>
				</div>
			</div>
			<div class="col-xs-6 col-sm-6 col-md-6">
				<div class="form-group">
					<label>Space:</label>
					<p>{{ $subscription->data_space }}</p>
				</div>
			</div>
			<div class="col-xs-12 col-sm-12 col-md-12">
				<div class="form-group">
					<label>Heading:</label>
					<p>{{ $subscription->heading }}</p>
				</div>
			</div>
			<div class="col-xs-12 col-sm-12 col-md-12">
				<div class="form-group">
					<label>Description:</label>
					<p>{{ strip_tags($subscription->description) }}</p>
				</div>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3">
				<div class="form-group">
					<label>Offer duration</label>
				</div>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3">
				<div class="form-group">
					<label>Offer percentage</label>
				</div>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3">
				<div class="form-group">
					<label>Offer Expire</label>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-3 col-sm-3 col-md-3">
				<div class="form-group">
					<p>{{ @$subscription->offer_duration1 }}</p>
				</div>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3">
				<div class="form-group">
					<p>{{ @$subscription->offer_percent1 }}</p>
				</div>
			</div>	
			<div class="col-xs-3 col-sm-3 col-md-3">
				<div class="form-group">
					<p>{{ @$subscription->offer_expiry1 }}</p>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-3 col-sm-3 col-md-3">
				<div class="form-group">
					<p>{{ @$subscription->offer_duration2 }}</p>
				</div>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3">
				<div class="form-group">
					<p>{{ @$subscription->offer_percent2 }}</p>
				</div>
			</div>	
			<div class="col-xs-3 col-sm-3 col-md-3">
				<div class="form-group">
					<p>{{ @$subscription->offer_expiry2 }}</p>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-3 col-sm-3 col-md-3">
				<div class="form-group">
					<p>{{ @$subscription->offer_duration3 }}</p>
				</div>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3">
				<div class="form-group">
					<p>{{ @$subscription->offer_percent3 }}</p>
				</div>
			</div>	
			<div class="col-xs-3 col-sm-3 col-md-3">
				<div class="form-group">
					<p>{{ @$subscription->offer_expiry3 }}</p>
				</div>
			</div>
		</div>
	</div>

@endsection