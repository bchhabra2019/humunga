@extends('Admin.admin_template')

@section('content')
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 margin-tb">								
				<div class="pull-left">					
					<h3>Member</h3>
				</div>	
				<div class="pull-right add-btn">
					<a class="btn btn-success" href="{{ route('members.create') }}" title="Member"> Create New</a>
				</div>
			</div>
		</div>
		@if ($message = Session::get('success'))
			<div class="alert alert-success">
				<p>{{ $message }}</p>
			</div>
		@endif
		<table id="datatable" class="table table-bordered dt-responsive nowrap">
			<thead>
				<tr>
					<th>No</th>
					<th>Image</th>
					<th>Name</th>
					<th>Email</th>
					<th>Contact</th>
					<th>Plan name</th>
					<th width="80px">Action</th>
				</tr>
			</thead>
			<tbody>
				@foreach ($member as $product)
				<tr class="item{{$product->id}}">
					<td>{{ ++$i }}</td>
					<td><img src="{{ url('admin/images/'.$product->image) }}" alt="{{ $product->image }}" width="100px" height="100px"></td>
					<td>{{ $product->name }}</td>
					<td>{{ $product->email }}</td>
					<td>{{ $product->phone }}</td>
					<td>
						@if($plan_details)
							@foreach($plan_details as $res)
								@if($res->user_id == $product->id)
									<span>{{ $res->plan_name }}</span>
								@endif
							@endforeach
						@endif
					</td>
					<td>
						<form action="{{ route('members.destroy',$product->id) }}" method="POST">
							<!--<a href="{{ route('members.show',$product->id) }}"><i class="fa fa-th-list fa-2x text-primary" title="Show"></i></a>-->
							<a href="{{ route('members.edit',$product->id) }}"><i class="fa fa-edit text-info fa-2x" title="Edit"></i></a>
							@csrf
							@method('DELETE')	   
							<button type="submit" class="form-icon"><i class="fa fa-trash fa-2x text-danger" title="Delete"></i></button>
						</form>
					</td>
				</tr>
				@endforeach
			</tbody>
		</table>
		{!! $member->links() !!}		   
	</div> <!-- container -->
	<script>
		$(document).ready(function() {
			$('#datatable').DataTable();
		} );
	</script>
@endsection