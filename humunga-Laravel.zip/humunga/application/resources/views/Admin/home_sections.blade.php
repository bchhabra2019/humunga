@extends('Admin.admin_template')

@section('content')
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 margin-tb">
				<div class="pull-left">
					<h3>Home Section</h3>
				</div>
			</div>
		</div>
		@if ($message = Session::get('success'))
			<div class="alert alert-success">
				<p>{{ $message }}</p>
			</div>
		@endif
		<table class="table table-bordered">
			<tr>
				<th>Section name</th>
				<th>Title</th>
				<th>Description</th>
				<th width="10%">Action</th>
			</tr>
			@if($services_resut)
				@foreach ($services_resut as $res)
				<tr>										
					<td>{{ $res->section_name }}</td>
					
					<td>{{ $res->title }}</td>
					
					<td>{{ $res->description }}</td>
					<td >
						<a href="{{ route('sections.edit',$res->id) }}"><i class="fa fa-edit fa-2x text-info" title="Edit"></i></a>						
					</td>
				</tr>
				@endforeach
			@else
				<tr>
					<td colspan="3">No recode found</td>
				</tr>
			@endif
		</table>	   
	</div> <!-- container -->
@endsection