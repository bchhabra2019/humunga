@extends('Admin.admin_template')

@section('content')
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 margin-tb">
				<div class="pull-left">
					<h3>Website Setting</h3>
				</div>
			</div>
		</div>
		@if ($message = Session::get('success'))
			<div class="alert alert-success">
				<p>{{ $message }}</p>
			</div>
		@endif
		<table class="table table-bordered">
			<tr>
				<th>Logo</th>
				<th>Email</th>
				<th>Phone</th>
				<th>Address</th>
				<th>Skype Address</th>
				<th>Action</th>
			</tr>
			@foreach ($websitesetting as $res)
			<tr>
				<td><img src="{{ url('admin/images/'.$res->logo) }}" width="100px" height="100px"></td>
				<td>{{ $res->email }}</td>
				<td>{{ $res->phone }}</td>
				<td>{{ $res->address }}</td>
				<td>{{ $res->skype_address }}</td>
				<td>
					<a href="{{ route('websitesetting.edit',$res->id) }}"><i class="fa fa-edit fa-2x text-info" title="Edit"></i></a>
				</td>
			</tr>
			@endforeach
		</table>	   
	</div> <!-- container -->
@endsection