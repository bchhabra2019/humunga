@extends('Admin.admin_template')

@section('content')
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 margin-tb">
				<div class="pull-left">
					<h3>System email</h3>
				</div>
				<div class="pull-right">
					<a class="btn btn-success" href="{{ route('systememail.create') }}"> Create New System email</a>
				</div>
			</div>
		</div>
		@if ($message = Session::get('success'))
			<div class="alert alert-success">
				<p>{{ $message }}</p>
			</div>
		@endif
		<table class="table table-bordered">
			<tr>
				<th>No</th>
				<th>Title</th>
				<th>Subject</th>
				<th>Message</th>
				<th width="150px">Action</th>
			</tr>
			@foreach ($systememails as $product)
			<tr>
				<td>{{ ++$i }}</td>
				<td>{{ $product->title }}</td>
				<td>{{ $product->subject }}</td>
				<td>{{ strip_tags($product->message) }}</td>
				<td>
					<form action="{{ route('systememail.destroy',$product->id) }}" method="POST">

						<a href="{{ route('systememail.show',$product->id) }}"><i class="fa fa-th-list fa-2x text-primary" title="Show"></i></a>
						<a href="{{ route('systememail.edit',$product->id) }}"><i class="fa fa-edit text-info fa-2x" title="Edit"></i></a>

						@csrf
						@method('DELETE')
	   
						<button type="submit"><i class="fa fa-trash fa-2x text-danger" title="Delete"></i></button>
					</form>
				</td>
			</tr>
			@endforeach
		</table>
		{!! $systememails->links() !!}		   
	</div> <!-- container -->
@endsection