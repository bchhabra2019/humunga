@extends('Admin.admin_template')

@section('content')
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 margin-tb">
				<div class="pull-left">
					<h3>System email</h3>
				</div>
				<div class="pull-right">
					<a class="btn btn-success" href="{{ route('systempages.create') }}"> Create New System Page</a>
				</div>
			</div>
		</div>
		@if ($message = Session::get('success'))
			<div class="alert alert-success">
				<p>{{ $message }}</p>
			</div>
		@endif
		<table class="table table-bordered">
			<tr>
				<th>No</th>
				<th>Name</th>
				<th>Heading</th>
				<th>Description</th>
				<th width="180px">Action</th>
			</tr>
			@foreach ($systempages as $product)
			<tr>
				<td>{{ ++$i }}</td>
				<td>{{ $product->name }}</td>
				<td>{{ $product->heading }}</td>
				<td>{{ strip_tags($product->description) }}</td>
				<td>
					<form action="{{ route('systempages.destroy',$product->id) }}" method="POST">

						<a href="{{ route('systempages.show',$product->id) }}"><i class="fa fa-th-list fa-2x text-primary" title="Show"></i></a>
						<a href="{{ route('systempages.edit',$product->id) }}"><i class="fa fa-edit text-info fa-2x" title="Edit"></i></a>

						@csrf
						@method('DELETE')
	   
						<button type="submit"><i class="fa fa-trash fa-2x text-danger" title="Delete"></i></button>
					</form>
				</td>
			</tr>
			@endforeach
		</table>
		{!! $systempages->links() !!}		   
	</div> <!-- container -->
@endsection