<!DOCTYPE html>
<html lang="en">    
	<head>
        <meta charset="utf-8" />
        <title>{{ $page_title or "Dashboard" }}</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="active-menu" content="{{ $menuId }}">
        <!-- App favicon -->
        <link rel="shortcut icon" href="{{ asset('/admin/images/favicon.ico') }}">

        <!--Morris Chart-->
        <link rel="stylesheet" href="{{ asset('/admin/libs/morris-js/morris.css') }}" />

        <!-- App css -->
        <link href="{{ asset('/admin/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" />
        <link href="{{ asset('/admin/css/icons.min.css')}}" rel="stylesheet" type="text/css" />
        <link href="{{ asset('/admin/css/app.min.css') }}" rel="stylesheet" type="text/css" />
    </head>

    <body>

        <!-- Begin page -->
        <div id="wrapper">

            <div class="content-page">
                <div class="content">
                   <div class="container-fluid">
						<div class="row offset-sm-2">
							<div class="col-xl-8 col-md-8">
                                <div class="card-box">

                                    <form class="form-horizontal" role="form" data-parsley-validate novalidate>
                                        <div class="form-group row">
											<div class="col-md-12">
												<label for="inputEmail3">Email*</label>
												<input type="email" required parsley-type="email" class="form-control" id="inputEmail3" placeholder="Email">
                                           </div>
                                        </div>
										<div class="form-group row">
											<div class="col-md-12">
												<label for="hori-pass1">Password*</label>
                                                <input id="hori-pass1" type="password" placeholder="Password" required class="form-control">
											</div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-12 offset-sm-4">
                                                <button type="submit" class="btn btn-primary waves-effect waves-light mr-1">
                                                    Login
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div><!-- end col -->
						</div>
					</div>					
                </div> <!-- content -->				
                <!-- Footer Start -->
                @include('Admin.footer')
                <!-- end Footer -->
            </div>
        </div>
        <!-- END wrapper -->

        <!-- Vendor js -->
        <script src="{{ asset('/admin/js/vendor.min.js') }}"></script>

        <!-- knob plugin -->
        <script src="{{ asset('/admin/libs/jquery-knob/jquery.knob.min.js') }}"></script>

        <!--Morris Chart-->
        <script src="{{ asset('/admin/libs/morris-js/morris.min.js') }}"></script>
        <script src="{{ asset('/admin/libs/raphael/raphael.min.js') }}"></script>

        <!-- Dashboard init js-->
        <script src="{{ asset('/admin/js/pages/dashboard.init.js') }}"></script>

        <!-- App js -->
        <script src="{{ asset('/admin/js/app.min.js') }}"></script>
        <script src="{{ asset('/admin/js/common.js') }}"></script>
        
    </body>

</html>