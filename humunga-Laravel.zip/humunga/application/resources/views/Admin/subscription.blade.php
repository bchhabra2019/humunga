@extends('Admin.admin_template')

@section('content')
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 margin-tb">				
				<div class="pull-right add-btn">
					<a class="btn btn-info" href="{{ route('subscription.create') }}"> Add New</a>
				</div>
			</div>
		</div>
		@if ($message = Session::get('success'))
			<div class="alert alert-success">
				<p>{{ $message }}</p>
			</div>
		@endif
		<table class="table table-bordered">
			<tr>
				<th>No</th>
				<th>Name</th>
				<th>Price</th>
				<th>Duration( Days )</th>
				<th>Space( GB )</th>
				<th>Heading</th>
				<th>Status</th>
				<th width="140px">Action</th>
			</tr>
			@foreach ($subscriptions as $product)
			<tr>
				<td>{{ ++$i }}</td>
				<td>{{ $product->name }}</td>
				<td>{{ $product->price }}</td>
				<td>{{ $product->duration }}</td>
				<td>{{ $product->data_space }}</td>
				<td>{{ $product->heading }}</td>
				<td>
					@if($product->status == 1)
						<span class="btn btn-success"> Active </span>
					@else
						<span class="btn btn-warning"> Inactive </span>						
					@endif
					<!--
					<span id="active_{{ $product->id }}" style="cursor:pointer" class="btn-group {{ ($product->status == 0)? 'display:none':'' }}" onClick="return setStatus({{ $product->id }}, '0')">
						<button class="btn btn-sm btn-success">ON</button>
						<button class="btn btn-sm btn-default">OFF</button>
					</span>
					<span id="inactive_{{ $product->id }}" style="cursor:pointer" class="btn-group {{ ($product->status == 1)? 'display:none':'' }}" onClick="return setStatus({{ $product->id }}, '1')">
						<button class="btn btn-sm btn-default">ON</button>
						<button class="btn btn-sm btn-success">OFF</button>
					</span>
					-->
				</td>
				<td>
					<form action="{{ route('subscription.destroy',$product->id) }}" method="POST" class="action-icons">

						<a href="{{ route('subscription.show',$product->id) }}"><i class="fa fa-th-list text-primary" title="Show"></i></a>
						<a href="{{ route('subscription.edit',$product->id) }}"><i class="fa fa-edit text-info " title="Edit"></i></a>

						@csrf
						@method('DELETE')
	   
						<button type="submit" class="form-icon"><i class="fa fa-trash text-danger" title="Delete"></i></button>
					</form>
				</td>
			</tr>
			@endforeach
		</table>
		{!! $subscriptions->links() !!}		   
	</div> <!-- container -->
@endsection