<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>

	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="author" content="SemiColonWeb" />
	<meta name="current-menu" content="{{ $Active_menu }}">
	<!-- Stylesheets
	============================================= -->
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700|Raleway:300,400,500,600,700|Crete+Round:400i" rel="stylesheet" type="text/css" />
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="{{ asset('/frontend/css/bootstrap.css') }}" type="text/css" />
	<link rel="stylesheet" href="{{ asset('/frontend/css/style.css') }}" type="text/css" />
	<link rel="stylesheet" href="{{ asset('/frontend/css/swiper.css') }}" type="text/css" />
	<link rel="stylesheet" href="{{ asset('/frontend/css/dark.css') }}" type="text/css" />
	<link rel="stylesheet" href="{{ asset('/frontend/css/font-icons.css') }}" type="text/css" />
	<link rel="stylesheet" href="{{ asset('/frontend/css/animate.css') }}" type="text/css" />
	<link rel="stylesheet" href="{{ asset('/frontend/css/bs-switches.css') }}" type="text/css" />
	<link rel="stylesheet" href="{{ asset('/frontend/css/magnific-popup.css') }}" type="text/css" />

	<link rel="stylesheet" href="{{ asset('/frontend/css/responsive.css') }}" type="text/css" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	<!-- Document Title
	============================================= -->
	<title>{{ $page_title or "Humunga" }}</title>

</head>

<body class="stretched">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

		@include('Frontend.layout.header')
		
		@include('Frontend.layout.slider')
		
		<!-- Content
		============================================= -->
		<section id="content">
		
			@yield('content')

		</section><!-- #content end -->

		@include('Frontend.layout.footer')
		
	</div><!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="icon-angle-up"></div>

	<!-- External JavaScripts
	============================================= -->
	<script src="{{ asset('/frontend/js/jquery.js') }}"></script>
	<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
	<script>
		@if(Session::has('message'))
			var type = "{{ Session::get('alert-type', 'info') }}"
			switch(type){
				case 'info':
					toastr.info("{{ Session::get('message') }}");	
					break;
				case 'success':
					toastr.success("{{ Session::get('message') }}");	
					break;
				case 'error':
					toastr.error("{{ Session::get('message') }}");	
					break;
				case 'warning':
					toastr.warning("{{ Session::get('message') }}");	
					break;
			}
		@endif
	</script>
	<script src="{{ asset('/frontend/js/plugins.js') }}"></script>

	<!-- Footer Scripts
	============================================= -->
	<script src="{{ asset('/frontend/js/functions.js') }}"></script>
	<script src="{{ asset('/frontend/js/switcher.js') }}"></script>
	<script>
		$(document).ready(function(){
			var element = $('meta[name="current-menu"]').attr('content');
			$('#' + element).addClass('current');
		});
	</script>	
</body>
</html>