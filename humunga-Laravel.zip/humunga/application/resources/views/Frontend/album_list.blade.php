@extends('Frontend.frontend_inner_template')



@section('content')

		<!-- Content
				============================================= -->
		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">

					<!-- Post Content
							============================================= -->
					<div class="nobottommargin clearfix">

						<!-- Portfolio Filter
							============================================= -->
						<ul class="portfolio-filter clearfix" data-container="#portfolio">

							<li class="activeFilter"><a href="#" data-filter="*">Show All</a></li>
							<li><a href="#" data-filter=".pf-icons">Wedding</a></li>
							<li><a href="#" data-filter=".pf-illustrations">Engagement</a></li>
							<li><a href="#" data-filter=".pf-uielements">Church</a></li>
							<li><a href="#" data-filter=".pf-media">Party</a></li>
							<li><a href="#" data-filter=".pf-graphics">Graphics</a></li>

						</ul>
						<!-- #portfolio-filter end -->
						<div class="clearfix"></div>

						<!-- Portfolio Items
							============================================= -->
						<div id="portfolio" class="portfolio grid-container clearfix">

							<article class="col-md-3 center topmargin-sm pf-graphics">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="{{ asset('/frontend/images/7.jpg') }}" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Open Imagination</a></h3>
									<span><a href="#">Media</a>, <a href="#">Icons</a></span>
								</div>
							</article>


							<article class="col-md-3 center topmargin-sm pf-icons">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="{{ asset('/frontend/images/album/1.jpg') }}" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Open Imagination</a></h3>
									<span><a href="#">Media</a>, <a href="#">Icons</a></span>
								</div>
							</article>

							<article class="col-md-3 center topmargin-sm pf-icons">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="{{ asset('/frontend/images/album/3.jpg') }}" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Locked Steel Gate</a></h3>
									<span><a href="#">Illustrations</a></span>
								</div>
							</article>

							<article class="col-md-3 center topmargin-sm pf-media">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="{{ asset('/frontend/images/album/6.jpg') }}" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Mac Sunglasses</a></h3>
									<span><a href="#">Graphics</a>, <a href="#">UI Elements</a></span>
								</div>
							</article>

							<article class="col-md-3 center topmargin-sm pf-illustrations">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="{{ asset('/frontend/images/album/2.jpg') }}" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Morning Dew</a></h3>
									<span><a href="#">Icons</a>, <a href="#">Illustrations</a></span>
								</div>
							</article>

							<article class="col-md-3 center topmargin-sm pf-graphics">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="{{ asset('/frontend/images/album/4.jpg') }}" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Console Activity</a></h3>
									<span><a href="#">UI Elements</a>, <a href="#">Media</a></span>
								</div>
							</article>

							<article class="col-md-3 center topmargin-sm pf-illustrations">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="{{ asset('/frontend/images/album/8.jpg') }}" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Shake It!</a></h3>
									<span><a href="#">Illustrations</a>, <a href="#">Graphics</a></span>
								</div>
							</article>

							<article class="col-md-3 center topmargin-sm pf-graphics pf-uielements">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="{{ asset('/frontend/images/album/3.jpg') }}" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Shake It!</a></h3>
									<span><a href="#">Illustrations</a>, <a href="#">Graphics</a></span>
								</div>
							</article>

							<article class="col-md-3 center topmargin-sm pf-uielements">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="{{ asset('/frontend/images/album/6.jpg') }}" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Shake It!</a></h3>
									<span><a href="#">Illustrations</a>, <a href="#">Graphics</a></span>
								</div>
							</article>

							<article class="col-md-3 center topmargin-sm pf-graphics">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="{{ asset('/frontend/images/album/1.jpg') }}" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Shake It!</a></h3>
									<span><a href="#">Illustrations</a>, <a href="#">Graphics</a></span>
								</div>
							</article>

							<article class="col-md-3 center topmargin-sm pf-illustrations">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="{{ asset('/frontend/images/album/3.jpg') }}" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Shake It!</a></h3>
									<span><a href="#">Illustrations</a>, <a href="#">Graphics</a></span>
								</div>
							</article>

							<article class="col-md-3 center topmargin-sm pf-icons">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="{{ asset('/frontend/images/7.jpg') }}" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Shake It!</a></h3>
									<span><a href="#">Illustrations</a>, <a href="#">Graphics</a></span>
								</div>
							</article>

						</div>
						<!-- #portfolio end -->

					</div>

				</div>

			</div>

		</section>
		<!-- #content end -->
@endsection