<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h3>{!! $heading !!} </h3>
		<div>
			<p><strong>Dear {!! $name !!}</strong>,</p>
			<p>Forgot password!</p>
			<p>Recently a request was submitted to reset a password for your account. If this was a mistake, just ignore this email and nothing will happen. To reset your password</p>
			<p>Visit the following link: <a href="{{ url($resetPassLink) }}">click here</a></p>
			<p><strong>Note:</strong> This link is valid only next 15 minutes valid</p>
			<p>Humunga team</p>
		</div>
	</body>
</html>