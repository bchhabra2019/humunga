@extends('Frontend.frontend_inner_template')

@section('content')
	
	 <!--Section 
  ============================================= -->
        <section id="slider" class="slider-element slider-parallax swiper_wrapper clearfix">
            <div class="slider-parallax-inner">
                <div class="swiper-container swiper-parent">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide dark" style="background-image: url('./frontend/images/example.jpg');background-size: cover; padding: 120px 0;" data-bottom-top="background-position:0px 0px;" data-top-bottom="background-position:0px -300px;">
                            <div class="col-lg-12 text-center" style="letter-spacing:2px">
                                <h1>EXAMPLES</h1>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                <a href="#" class="btn btn-primary get-started" style="background: #1ABC9C; padding: 10px 50px;	margin: 15px 0 7px; border: none">GET STARTED</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- section end -->

        <div class="clear"></div>

        <!-- Content
  ============================================= -->
        <section id="content">
            <div class="content-wrap">
                <div class="container clearfix">
                    <div class="row grid-container" data-layout="masonry" style="overflow: visible">
                        <div class="col-6 col-lg-4 ani-trans ">
                            <a href="#">
                                <img alt="100%x180" src="{{ asset('/frontend/images/featured/1.jpg') }}" class="img-thumbnail">
                            </a>
                            <h4 class="text-center">JASMINE STAR<br><small>Wedding</small></h4>
                        </div>
                        <div class="col-6 col-lg-4 ani-trans">
                            <a href="#">
                                <img alt="100%x180" src="{{ asset('/frontend/images/featured/2.jpg') }}" class="img-thumbnail">
                            </a>
                            <h4 class="text-center">JASMINE STAR<br><small>Family</small></h4>
                        </div>
                        <div class="col-6 col-lg-4 ani-trans">
                            <a href="#">
                                <img alt="100%x180" src="{{ asset('/frontend/images/featured/3.jpg') }}" class="img-thumbnail">
                            </a>
                            <h4 class="text-center">JASMINE STAR<br><small>Event</small></h4>
                        </div>

                        <div class="col-6 col-lg-4 ani-trans">
                            <a href="#">
                                <img alt="100%x180" src="{{ asset('/frontend/images/featured/1.jpg') }}" class="img-thumbnail">
                            </a>
                            <h4 class="text-center">JASMINE STAR<br><small>Wedding</small></h4>
                        </div>

                        <div class="col-6 col-lg-4 ani-trans">
                            <a href="#">
                                <img alt="100%x180" src="{{ asset('/frontend/images/featured/2.jpg') }}" class="img-thumbnail">
                            </a>
                            <h4 class="text-center">JASMINE STAR<br><small>Family</small></h4>
                        </div>

                        <div class="col-6 col-lg-4 ani-trans">
                            <a href="#">
                                <img alt="100%x180" src="{{ asset('/frontend/images/featured/3.jpg') }}" class="img-thumbnail">
                            </a>
                            <h4 class="text-center">JASMINE STAR<br><small>Event</small></h4>
                        </div>

                        <div class="col-6 col-lg-4 ani-trans">
                            <a href="#">
                                <img alt="100%x180" src="{{ asset('/frontend/images/featured/1.jpg') }}" class="img-thumbnail">
                            </a>
                            <h4 class="text-center">JASMINE STAR<br><small>Wedding</small></h4>
                        </div>

                        <div class="col-6 col-lg-4 ani-trans">
                            <a href="#">
                                <img alt="100%x180" src="{{ asset('/frontend/images/featured/2.jpg') }}" class="img-thumbnail">
                            </a>
                            <h4 class="text-center">JASMINE STAR<br><small>Family</small></h4>
                        </div>

                        <div class="col-6 col-lg-4 ani-trans">
                            <a href="#">
                                <img alt="100%x180" src="{{asset('/frontend/images/featured/3.jpg')}}" class="img-thumbnail">
                            </a>
                            <h4 class="text-center">JASMINE STAR<br><small>Event</small></h4>
                        </div>

                        <div class="col-6 col-lg-4 ani-trans">
                            <a href="#">
                                <img alt="100%x180" src="{{ asset('/frontend/images/featured/1.jpg') }}" class="img-thumbnail">
                            </a>
                            <h4 class="text-center">JASMINE STAR<br><small>Wedding</small></h4>
                        </div>

                        <div class="col-6 col-lg-4 ani-trans">
                            <a href="#">
                                <img alt="100%x180" src="{{ asset('/frontend/images/featured/2.jpg') }}" class="img-thumbnail">
                                <h4 class="text-center">JASMINE STAR<br><small>Family</small></h4>
                            </a>
                        </div>

                        <div class="col-6 col-lg-4 ani-trans">
                            <a href="#">
                                <img alt="100%x180" src="{{ asset('/frontend/images/featured/3.jpg') }}" class="img-thumbnail">
                            </a>
                            <h4 class="text-center">JASMINE STAR<br><small>Event</small></h4>
                        </div>

                    </div>

                </div>
            </div>

        </section>
        <!-- content end -->

        <!-- Go To Top
	============================================= -->
        <div id="gotoTop" class="icon-angle-up"></div>

        <!-- Content
    ============================================= -->
        <div class="section parallax dark nomargin noborder" style="padding: 150px 0; background-image: url('./frontend/images/footer.jpg');" data-bottom-top="background-position:0px 0px;" data-top-bottom="background-position:0px -300px;">
            <div class="container center clearfix">

                <div class="emphasis-title">
                    <h2>Perfect tool for Customization</h2>
                    <p class="lead topmargin-sm">Create as much unique content as you want with this Template which has powerful &amp; optimized code.</p>
                </div>

                <a href="#" class="button button-border button-rounded button-light button-large">Get Started</a>

            </div>
        </div>
        <!-- #content end -->
	
@endsection