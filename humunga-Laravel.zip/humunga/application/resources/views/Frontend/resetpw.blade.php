<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="author" content="SemiColonWeb" />
	<!-- Stylesheets ============================================= -->
	<link href="http://fonts.googleapis.com/css?family=Lora:400,400i,700,700i|Lato:300,400,600,700|Parisienne" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="{{ asset('/frontend/css/bootstrap.css') }}" type="text/css" />
	<link rel="stylesheet" href="{{ asset('/frontend/css/style.css') }}" type="text/css" />
	<link rel="stylesheet" href="{{ asset('/frontend/css/dark.css') }}" />
	<link rel="stylesheet" href="{{ asset('/frontend/css/onepage.css') }}" />

	<!-- Writer Demo Specific Stylesheet -->
	<!--<link rel="stylesheet" href="writer.css" type="text/css" />-->
	
	<!-- / -->

	<link rel="stylesheet" href="{{ asset('/frontend/css/font-icons.css') }}" type="text/css" />
	<link rel="stylesheet" href="{{ asset('/frontend/css/animate.css') }}" type="text/css" />
	<link rel="stylesheet" href="{{ asset('/frontend/css/magnific-popup.css') }}" type="text/css" />

	<!-- Writer Demo Specific Stylesheet -->
	<link rel="stylesheet" href="{{ asset('/frontend/css/colors.css') }}" type="text/css" />
	<link rel="stylesheet" href="{{ asset('/frontend/css/fonts.css') }}" type="text/css" />
	<!-- / -->

	<link rel="stylesheet" href="{{ asset('/frontend/css/responsive.css') }}" type="text/css" />
	<link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">
	<meta name="viewport" content="width=device-width, initial-scale=1" />

	<!-- Document Title
	============================================= -->
	<title>{{ $page_title or "Humunga" }}</title>

</head>

<body class="stretched">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap nopadding">

				<div class="section nopadding move-bg nomargin" style="width: 100%; height: 100%; position: absolute; left: 0; top: 0; background: url({{asset('/frontend/images/slider/header_image.jpg')}}) center center no-repeat; background-size: cover;"></div>

				<div class="section nobg full-screen force-full-screen nopadding nomargin">
					<div class="container-fluid vertical-middle divcenter clearfix">					
					
						<div class="card divcenter dark rounded border border-dark shadow-lg" style="max-width: 540px; background-color: rgba(30,30,30,0.9)">
							@if ($errors->any())
								<div class="alert alert-danger">
									<strong>Whoops!</strong> There were some problems with your input.<br><br>
									<ul>
										@foreach ($errors->all() as $error)
											<li>{{ $error }}</li>
										@endforeach
									</ul>
								</div>
							@endif	
							<h3 class="card-footer py-4 center">Change Password</h3>
							<div class="card-body divcenter py-5" style="max-width: 100%;">

								<form id="login-form" name="login-form" class="nobottommargin row"  novalidate action="{{ url('signin/resetpwpro') }}" method="POST">
								@csrf
		
									<div class="col-12">
										<label>New Password<span class="text-danger">*</span></label>
										<input type="hidden" id="UId" name="UId" class="form-control hidden" value="{{ $UId }}" />
										<input type="hidden" id="token" name="token" class="form-control hidden" value="{{ $token }}" />
										<input type="password" id="password" name="password" class="form-control not-dark" placeholder="New password" />
									</div>
									<div class="col-12">
										<label>Confirm Password<span class="text-danger">*</span></label>
										<input type="password" id="confirmed" name="password_confirmation" class="form-control not-dark" placeholder="Confirm password" />
									</div>
									
									<div class="col-12 mt-4">
										<button class="button button-rounded btn-block nomargin" id="login-form-submit" name="login-form-submit" value="login">Login</button>
									</div>
								</form>
							</div>
							<div class="card-footer py-4 center">
								<p class="mb-0">&nbsp;</p>
							</div>
						</div>

						<div class="center dark mt-3"><small>Copyrights &copy; All Rights Reserved by Hungama.</small></div>
					</div>
				</div>
			</div>
		</section>

	</div><!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="icon-angle-up"></div>

	<!-- External JavaScripts
	============================================= -->
	<script src="{{ asset('/frontend/js/jquery.js') }}"></script>
	<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
	<script>
		@if(Session::has('message'))
			var type = "{{ Session::get('alert-type', 'info') }}"
			switch(type){
				case 'info':
					toastr.info("{{ Session::get('message') }}");	
					break;
				case 'success':
					toastr.success("{{ Session::get('message') }}");	
					break;
				case 'error':
					toastr.error("{{ Session::get('message') }}");	
					break;
				case 'warning':
					toastr.warning("{{ Session::get('message') }}");	
					break;
			}
		@endif
	</script>
	<script src="{{ asset('/frontend/js/plugins.js') }}"></script>
	<script src="{{ asset('/frontend/js/hover3d.js') }}"></script>

	<!-- Footer Scripts
	============================================= -->
	<script src="{{ asset('/frontend/js/functions.js') }}"></script>

	<script>

		jQuery(document).ready( function(){

			if( !jQuery('body').hasClass('device-touch') ) {

				var lFollowX = 0,
					lFollowY = 0,
					x = 0,
					y = 0,
					friction = 1 / 30;

				function moveBackground() {
					x += (lFollowX - x) * friction;
					y += (lFollowY - y) * friction;

					translate = 'translate(' + x + 'px, ' + y + 'px) scale(1.1)';

					jQuery('.move-bg').css({
						'-webit-transform': translate,
						'-moz-transform': translate,
						'transform': translate
					});

					window.requestAnimationFrame(moveBackground);
				}

				jQuery(window).on('mousemove click', function(e) {

					var lMouseX = Math.max(-100, Math.min(100, jQuery(window).width() / 2 - e.clientX));
					var lMouseY = Math.max(-100, Math.min(100, jQuery(window).height() / 2 - e.clientY));
					lFollowX = (10 * lMouseX) / 100; // 100 : 12 = lMouxeX : lFollow
					lFollowY = (10 * lMouseY) / 100;

				});

				moveBackground();

			}

		});
	</script>
</body>
</html>