<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h3>{!! $heading !!} </h3>
		<div>
			<p><strong>Dear {!! $name !!}</strong>,</p>
			<p>Change password!</p>			
			<p>Your password change successfull <br/> Login: <a href="{{ url('/signin') }}">click here</a></p>
			<p>Humunga team</p>
		</div>
	</body>
</html>