@extends('Frontend.frontend_inner_template')

@section('content')
	
		<!--Section 
  ============================================= -->
        <section id="slider" class="slider-element slider-parallax swiper_wrapper clearfix">
            <div class="slider-parallax-inner">
                <div class="swiper-container swiper-parent">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide dark" style="background-image: url('./frontend/images/upgrade.jpg');background-size: cover; padding: 120px 0;" data-bottom-top="background-position:0px 0px;" data-top-bottom="background-position:0px -300px;">
                            <div class="col-lg-12 text-center" style="letter-spacing:2px">
                                <h1>UPGRADE WHEN YOU NEED TO</h1>
                                <p>Flexible plans that scale with your business.</p>
                                <a href="#" class="btn btn-primary get-started" style="background: #1ABC9C; padding: 10px 50px; margin: 15px 0 7px; border: none">GET STARTED</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- section end -->

        <div class="clear"></div>
        <!-- Content
============================================= -->
        <section id="content">
            <div class="content-wrap">
                <div class="container clearfix">
                    <div class="fancy-title title-dotted-border title-center">
                        <h3>Pricing with Toggle switcher</h3>
                    </div>
                    <div id="section-pricing" class="page-section nopadding nomargin">
                        <div class="pricing-tenure-switcher center bottommargin-sm" data-container="#pricing-switch">
                            <span class="pts-left">Monthly</span>
                            <div class="pts-switcher">
                                <div class="switch">
                                    <input id="switch-toggle-pricing-tenure" class="switch-toggle switch-toggle-round" type="checkbox">
                                    <label for="switch-toggle-pricing-tenure"></label>
                                </div>
                            </div>
                            <span class="pts-right">Yearly</span>
                        </div>
                        <div id="pricing-switch" class="pricing row bottommargin-lg clearfix">
							@if($subscription_details)
								@foreach($subscription_details as $res)
									<div class="col-lg-4 col-md-6">
										<div class="pricing-box">
											<div class="pricing-title">
												<h3>{{ $res->name }}</h3>
												<span>{{ $res->heading }}</span>
											</div>
											<div class="pricing-price">
												@if($res->price > 0)
													{{ $res->price }}													
												@else
													FREE
												@endif
											</div>
											<div class="pricing-features">
												{!! $res->description !!}
											</div>
											<div class="pricing-action">
												<a href="#" class="button button-large button-rounded capitalize ls0" style="border-radius: 23px;">Get Started</a>
											</div>
										</div>
									</div>
								@endforeach
							@endif
							<!--
                            <div class="col-lg-4 col-md-6">
                                <div class="pricing-box">
                                    <div class="pricing-title">
                                        <h3>Starter</h3>
                                    </div>
                                    <div class="pricing-price">
                                        FREE
                                    </div>
                                    <div class="pricing-features">
                                        <ul>
                                            <li><strong>Full</strong> Access</li>
                                            <li><i class="icon-code"></i> Source Files</li>
                                            <li><strong>100</strong> User Accounts</li>
                                            <li><strong>1 Year</strong> License</li>
                                            <li>Phone Email Support</li>
                                        </ul>
                                    </div>
                                    <div class="pricing-action">
                                        <a href="#" class="button button-large button-rounded capitalize ls0" style="border-radius: 23px;">Get Started</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6">
                                <div class="pricing-box best-price">
                                    <div class="pricing-title">
                                        <h3>Professional</h3>
                                        <span>Most Popular</span>
                                    </div>
                                    <div class="pricing-price">
                                        <div class="pts-switch-content-left"><span class="price-unit"></span>12</div>
                                        <div class="pts-switch-content-right"><span class="price-unit"></span>99</div>
                                    </div>
                                    <div class="pricing-features">
                                        <ul>
                                            <li><strong>Full</strong> Access</li>
                                            <li><i class="icon-code"></i> Source Files</li>
                                            <li><strong>1000</strong> User Accounts</li>
                                            <li><strong>2 Years</strong> License</li>
                                            <li><i class="icon-star3"></i>
                                                <i class="icon-star3"></i>
                                                <i class="icon-star3"></i>
                                                <i class="icon-star3"></i>
                                                <i class="icon-star3"></i>
											</li>
                                        </ul>
                                    </div>
                                    <div class="pricing-action">
                                        <div class="pts-switch-content-left">
											<a href="#" class="button button-large button-rounded capitalize ls0" style="border-radius: 23px;">Start Free Trial</a>
										</div>
                                        <div class="pts-switch-content-right">
											<a href="#" class="button button-large button-rounded capitalize ls0" style="border-radius: 23px;">Start Free Trial</a>
										</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 offset-lg-0 col-md-6 offset-md-3">
                                <div class="pricing-box">
                                    <div class="pricing-title">
                                        <h3>Business</h3>
                                    </div>
                                    <div class="pricing-price">
                                        <div class="pts-switch-content-left"><span class="price-unit"></span>19</div>
                                        <div class="pts-switch-content-right"><span class="price-unit"></span>149</div>
                                    </div>
                                    <div class="pricing-features">
                                        <ul>
                                            <li><strong>Full</strong> Access</li>
                                            <li><i class="icon-code"></i> Source Files</li>
                                            <li><strong>500</strong> User Accounts</li>
                                            <li><strong>3 Years</strong> License</li>
                                            <li>Phone Email Support</li>
                                        </ul>
                                    </div>
                                    <div class="pricing-action">
                                        <div class="pts-switch-content-left">
											<a href="#" class="button button-large button-rounded capitalize ls0" style="border-radius: 23px;">Start Free Trial</a>
										</div>
                                        <div class="pts-switch-content-right">
											<a href="#" class="button button-large button-rounded capitalize ls0" style="border-radius: 23px;">Start Free Trial</a>
										</div>
                                    </div>
                                </div>
                            </div>
							-->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- #content end -->

        <!-- Go To Top
	============================================= -->
        <div id="gotoTop" class="icon-angle-up"></div>

        <!-- Content
    ============================================= -->
        <div class="section parallax dark nomargin noborder" style="padding: 150px 0; background-image: url('./frontend/images/footer.jpg');" data-bottom-top="background-position:0px 0px;" data-top-bottom="background-position:0px -300px;">
            <div class="container center clearfix">
                <div class="emphasis-title">
                    <h2>Perfect tool for Customization</h2>
                    <p class="lead topmargin-sm">Create as much unique content as you want with this Template which has powerful &amp; optimized code.</p>
                </div>
                <a href="#" class="button button-border button-rounded button-light button-large">Get Started</a>
            </div>
        </div>
        <!-- #content end -->	
@endsection