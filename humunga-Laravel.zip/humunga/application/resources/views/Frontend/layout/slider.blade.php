<section id="slider" class="slider-element slider-parallax swiper_wrapper full-screen clearfix">
	<div class="slider-parallax-inner">
		<div class="swiper-container swiper-parent">
			<div class="swiper-wrapper">
				@if($slider_resut)
					@foreach($slider_resut as $value)
						@if($value->type == 'Home')
							<div class="swiper-slide dark" style="background-image: url('application/public/admin/images/{{ $value->image }}');">
								<div class="container clearfix">
									<div class="slider-caption slider-caption-center">
										<h2 data-animate="fadeInUp">
											<img src="{{ asset('application/public/admin/images/'.$value->icon) }}">
										</h2>									
									</div>
								</div>
							</div>								
						@endif
					@endforeach					
				@endif
			</div>
			<div class="slider-arrow-left"><i class="icon-angle-left"></i></div>
			<div class="slider-arrow-right"><i class="icon-angle-right"></i></div>
		</div>
		<a href="#" data-scrollto="#content" data-offset="100" class="dark one-page-arrow">
		<i class="icon-angle-down infinite animated fadeInDown"></i></a>
	</div>
</section>
