<!-- Header
		============================================= -->
		<header id="header" class="transparent-header full-header" data-sticky-class="not-dark">

			<div id="header-wrap">

				<div class="container clearfix">

					<div id="primary-menu-trigger"><i class="icon-reorder"></i></div>

					<!-- Logo
					============================================= -->
					<div id="logo">
						<a href="{{ url('home') }}" class="standard-logo" data-dark-logo="{{ asset('/frontend/images/logo-tex-blckt.png') }}">
							<img src="{{ asset('/frontend/images/logo-tex-blckt.png') }}" />
						</a>
						<a href="{{ url('home') }}" class="retina-logo" data-dark-logo="{{ asset('/frontend/images/logo-tex-blckt.png') }}">
							<img src="{{ asset('/frontend/images/logo-tex-blckt.png') }}" />
						</a>
					</div><!-- #logo end -->

					<!-- Primary Navigation
					============================================= -->
					<nav id="primary-menu">
						<ul>
							<li id="Tour">
								<a href="{{ url('tour') }}"><div>Features</div></a>
							</li>
							<li id="Example">
								<a href="{{ url('example') }}"><div>Examples</div></a>
							</li>
							<li id="Upgrade">
								<a href="{{ url('upgrade') }}"><div>Upgrade</div></a>
							</li>
							@if(Session::get('ID'))
								<li id="Dashboard" class="current">
									<a href="{{ url('/album') }}"><div>{{ Session::get('uname') }}</div></a>
								</li>				
								<li>
									<a href="{{ url('/logout') }}"><div>Logout</div></a>
								</li>							
							@else
								<li id="Login">
									<a href="{{ url('signin') }}"><div>LOGIN</div></a>
								</li>
								<li id="SignUp">
									<a href="{{ url('signup') }}"><div>SIGNUP</div></a>
								</li>
							@endif	
						</ul>						
						<!-- Top Search
						============================================= -->						
					</nav><!-- #primary-menu end -->

				</div>

			</div>

		</header><!-- #header end -->