<!-- Footer
		============================================= -->
		<footer id="footer" class="dark">

			<div class="container">

				<!-- Footer Widgets
				============================================= -->
				<div class="footer-widgets-wrap clearfix">

					<div class="col_one_third">

						<div class="widget widget_links clearfix">

							<h3>PRODUCT</h3>

							<ul>

								<li><a href="#">Client Gallery</a></li>
								<li><a href="#">Mobile Gallery Application</a></li>
								<li><a href="#">Examples</a></li>
								<li><a href="#">Upgrade</a></li>
								<li><a href="#">Feature List</a></li>
								<li><a href="#">Tools</a></li>

								
							</ul>

						</div>

					</div>

					<div class="col_one_third">

						<div class="widget widget_links clearfix">

							<h3>COMPANY</h3>

							<ul>

								<li><a href="#">About US</a></li>
								<li><a href="#">Careers</a></li>
								<li><a href="#">Help and Support</a></li>
								<li><a href="#">Terms of Service</a></li>									
								<li><a href="#">Privacy Policy</a></li>
								
							</ul>

						</div>

					</div>

					<div class="col_one_third col_last">
						<div class="widget clearfix">							
							<a href="#" class="social-icon si-colored si-github">
								<i class="icon-facebook"></i>
								<i class="icon-facebook"></i>
							</a>
							<a href="#" class="social-icon si-colored si-github">
								<i class="icon-instagram"></i>
								<i class="icon-instagram"></i>
							</a>
							
							<a href="#" class="social-icon si-colored si-github">
								<i class="icon-twitter"></i>
								<i class="icon-twitter"></i>
							</a>
						</div>

					</div>

				</div><!-- .footer-widgets-wrap end -->

			</div>

			<!-- Copyrights
			============================================= -->
			<div id="copyrights">

				<div class="container clearfix">

					<div class="col_half">
						Copyrights &copy; 2019 All Rights Reserved by Humunga Inc.<br>
						<div class="copyright-links"><a href="#">Terms of Use</a> / <a href="#">Privacy Policy</a></div>
					</div>

					<div class="col_half col_last tright">
						<div class="fright clearfix">
							<a href="#" class="social-icon si-small si-borderless si-facebook">
								<i class="icon-facebook"></i>
								<i class="icon-facebook"></i>
							</a>

							<a href="#" class="social-icon si-small si-borderless si-twitter">
								<i class="icon-twitter"></i>
								<i class="icon-twitter"></i>
							</a>

							<a href="#" class="social-icon si-small si-borderless si-pinterest">
								<i class="icon-pinterest"></i>
								<i class="icon-pinterest"></i>
							</a>

							<a href="#" class="social-icon si-small si-borderless si-vimeo">
								<i class="icon-vimeo"></i>
								<i class="icon-vimeo"></i>
							</a>

							<a href="#" class="social-icon si-small si-borderless si-github">
								<i class="icon-github"></i>
								<i class="icon-github"></i>
							</a>

							<a href="#" class="social-icon si-small si-borderless si-yahoo">
								<i class="icon-yahoo"></i>
								<i class="icon-yahoo"></i>
							</a>

							<a href="#" class="social-icon si-small si-borderless si-linkedin">
								<i class="icon-linkedin"></i>
								<i class="icon-linkedin"></i>
							</a>
						</div>

						<div class="clear"></div>

						<i class="icon-envelope2"></i> info@humunga.com <span class="middot">&middot;</span> 
						<i class="icon-headphones"></i> +91-11-1234-5678 <span class="middot">&middot;</span> 
						<i class="icon-skype2"></i> HumungaOnSkype
					</div>

				</div>

			</div><!-- #copyrights end -->

		</footer><!-- #footer end -->
		
		<!--modal-->
		<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-body">
					<div class="modal-content">
						<div class="modal-header">
							<h3 style="width: 100%;text-align:center;">Create New Album<span class="subtitle"></span></h3>
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						</div>
						<div class="modal-body">
							<form style="max-width: 25rem;" action="#" method="post" onsubmit="return validationAlbum()">
								<div class="form-group">
									<label for="exampleInputEmail1">Album Name</label>
									<input type="text" class="form-control" id="album_name" name="album_name" aria-describedby="emailHelp" placeholder="e.g. John">
									<small id="emailHelp" class="form-text text-muted">We'll never share your album to  anyone else without security.</small>
								</div>
								<div class="form-group input-daterange travel-date-group">
									<label for="">Date</label>									
									<div class="input-group">
										<input type="text" name="create_date" id="create_date" class="form-control tleft today" placeholder="MM/DD/YYYY">
										<div class="input-group-append">
											<div class="input-group-text"><i class="icon-calendar2"></i></div>
										</div>
									</div>
								</div>
								<div class="form-row travel-date-group">
									<div class="form-group col-md-6">
										<label>Tag your Album</label>
										<input type="text" name="album_tag" id="album_tag" class="form-control">
									</div>
									<div class="form-group col-md-6">
										<label>Auto Expiry</label>
										<input type="text" name="expiry_date" id="expiry_date" class="form-control tleft today">										
									</div>
								</div>
								<div style="text-align: right">
									<button type="submit" id="create" class="button button-small button-rounded">Create</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>