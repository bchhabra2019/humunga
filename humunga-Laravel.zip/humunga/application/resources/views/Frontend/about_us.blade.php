@extends('Frontend.frontend_inner_template')

@section('content')
	<section id="page-title" class="page-title-parallax page-title-dark" style="background-image: url('./frontend/images/slider/aboutus-bg.jpg'); background-size: cover; padding: 120px 0;" data-bottom-top="background-position:0px 0px;" data-top-bottom="background-position:0px -300px;">

		<div class="container clearfix">
			<h1>ABOUT-US</h1>
			<span>Lorem ipsum dolor sit amet</span>
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="/">Home</a></li>				
				<li class="breadcrumb-item active" aria-current="page">AboutUS</li>
			</ol>
		</div>

	</section>
	<!-- #page-title end -->

	<div class="clear"></div>
	<!-- Content
			============================================= -->
	<section id="content">
		<div class="content-wrap notoppadding nobottompadding">
			<!-- WE are Snapics -->
			<div class="section nobottommargin notopmargin bgcolor-black aboutme-note">
				<div class="container clear-bottommargin clearfix">
					<div class="row topmargin-sm clearfix">
						<div class="col-lg-6 bottommargin border-right">
							<div class="emphasis-title">
								<h2 class="font-white" style="padding-top: 50px"><strong>WHO WE ARE?</strong></h2>
							</div>
						</div>
						<div class="col-lg-6 bottommargin ">
							<p class="topmargin-sm font-white">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
						</div>

					</div>

				</div>

			</div>

			<!--//-->

			<!---->
			<div class="section">
				<div class="container clearfix">
					<div class="heading-block center nobottomborder nobottommargin">
						<h2>Perfect tool for Customization</h2>
						<p class="lead topmargin-sm">Create as much unique content as you want with this Template which has powerful &amp; optimized code.</p>
						<a href="#" class="button button-rounded button-aqua button-light button-large">Tour</a>
						<a href="#" class="button button-rounded button-green button-large">Get Started</a>
					</div>

				</div>
			</div>

			<!--welcome note-->

		</div>
		<!--welcome note end-->
		<div class="clear"></div>

		<!--parallax section-->
		<div class="section parallax full-screen dark nomargin noborder" style="background-image: url('./frontend/images/about2.jpg');" data-bottom-top="background-position:0px 0px;" data-top-bottom="background-position:0px -300px;">
			<div class="vertical-middle">
				<div class="container clearfix">

					<div class="row">

						<div class="col_one_third nobottommargin center">
							<i class="i-plain i-xlarge divcenter nobottommargin icon-location"></i>
							<div class="counter counter-large" style="color: #1abc9c;"><span data-from="100" data-to="8465" data-refresh-interval="50" data-speed="2000"></span></div>
							<h5>Clients Served</h5>
						</div>

						<div class="col_one_third nobottommargin center">
							<i class="i-plain i-xlarge divcenter nobottommargin icon-camera2"></i>
							<div class="counter counter-large" style="color: #e74c3c;"><span data-from="100" data-to="56841" data-refresh-interval="50" data-speed="2500"></span></div>
							<h5>Images</h5>
						</div>

						<div class="col_one_third col_last nobottommargin center">
							<i class="i-plain i-xlarge divcenter nobottommargin icon-image"></i>
							<div class="counter counter-large" style="color: #3498db;"><span data-from="100" data-to="2154" data-refresh-interval="50" data-speed="3500"></span></div>
							<h5>Lorem Ipsum</h5>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="clear"></div>

		<!--parallax section end-->
		<div class="row nopadding align-items-stretch ohidden">
			<div class="col-lg-6 col-padding" style="background: url('./frontend/images/parallax/big.jpg') center center no-repeat; background-size: cover;">
				<div>&nbsp;</div>
			</div>
			<div class="col-lg-6 col-padding">

				<div>
					<div class="heading-block">
						<h3>Powerful insights to help grow your business.</h3>
					</div>

					<div class="row">
						<div class="col-md-9 nopadding topmargin-sm clearfix">

							<div class="feature-box fbox-outline fbox-light fbox-effect" data-animate="fadeIn">
								<div class="fbox-icon">
									<a href="#"><i class="icon-line-monitor"></i></a>
								</div>
								<h3>Lorem Ipsum</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
							</div>

							<div class="feature-box fbox-outline fbox-light fbox-effect topmargin" data-animate="fadeIn" data-delay="200">
								<div class="fbox-icon">
									<a href="#"><i class="icon-line-eye"></i></a>
								</div>
								<h3>Lorem Ipsum</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
							</div>

							<div class="feature-box fbox-outline fbox-light fbox-effect topmargin" data-animate="fadeIn" data-delay="400">
								<div class="fbox-icon">
									<a href="#"><i class="icon-line-layers"></i></a>
								</div>
								<h3>Lorem ipsum dolor</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
							</div>

						</div>
					</div>
				</div>

			</div>
		</div>

		<div class="clear"></div>

		<!--//-->
		<div class="row nopadding align-items-stretch ohidden">

			<div class="col-lg-6 col-padding">

				<div>
					<div class="heading-block">
						<h3>Powerful insights to help grow your business.</h3>
					</div>

					<div class="row">
						<div class="col-md-9 nopadding topmargin-sm clearfix">

							<div class="feature-box fbox-outline fbox-light fbox-effect" data-animate="fadeIn">
								<div class="fbox-icon">
									<a href="#"><i class="icon-line-monitor"></i></a>
								</div>
								<h3>Lorem Ipsum</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
							</div>

							<div class="feature-box fbox-outline fbox-light fbox-effect topmargin" data-animate="fadeIn" data-delay="200">
								<div class="fbox-icon">
									<a href="#"><i class="icon-line-eye"></i></a>
								</div>
								<h3>Lorem Ipsum</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
							</div>

							<div class="feature-box fbox-outline fbox-light fbox-effect topmargin" data-animate="fadeIn" data-delay="400">
								<div class="fbox-icon">
									<a href="#"><i class="icon-line-layers"></i></a>
								</div>
								<h3>Lorem ipsum dolor</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
							</div>

						</div>
					</div>
				</div>

			</div>
			<div class="col-lg-6 col-padding" style="background: url('./frontend/images/about3.jpg') center center no-repeat; background-size: cover;">
				<div>&nbsp;</div>
			</div>
		</div>

		<div class="clear"></div>
		<!--image section start-->

		<!--image section end-->

		<!--//-->

	</section>
<!-- #content end -->
@endsection