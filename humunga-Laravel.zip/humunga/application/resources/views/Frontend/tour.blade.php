@extends('Frontend.frontend_inner_template')



@section('content')

		<!--Section 

		============================================= -->

		<section id="slider" class="slider-element force-full-screen clearfix" style="padding-bottom:50px; top:0">

			<div class="force-full-screen full-screen dark" style="background-image: url('./frontend/images/tour.jpg');background-size: cover; padding:  120px;background-position: bottom;position: relative;top:0px;" data-bottom-top="background-position:0px 0px;" data-top-bottom="background-position:100% ;">

				<div class="container clearfix" style="text-align:center; color: black ">

					<div class="head-section" style="position: relative;bottom:100px;">

						<h1 style="color:black;" class="h1-modify">Lorem ipsum dolor sit amet</h1>

						<p style="position: relative;bottom:30px;">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>

						<a href="#" class="btn btn-primary get-started start-section" style="background: #1ABC9C; padding: 10px 50px;position: relative;bottom:50px; margin:0; border: none; border-radius: 0">GET STARTED</a>

						<p class="btn-desc" style="position:relative;bottom:40px;">Free forever. Upgrade when you need to.</p>

					</div>

				</div>

			</div>

		</section>

		<!-- Section end -->



		<!-- Entry Image

							============================================= -->

		<div class="entry-image bottommargin">

			<a href="#">

				<img src="{{ asset('/frontend/images/slider/rev/ken-2.jpg') }}" alt="Blog Single">

			</a>

		</div>

		<!-- .entry-image end -->



		<!-- Middle Section -->

		<div>

			<div class="container clearfix">



				<div id="section-nextgen" class="page-section bottommargin-lg">

					<div class="row clearfix">



						<div class="col-lg-7 center">

							<img src="{{ asset('/frontend/images/section/iphone-watch.png') }}" alt="NextGen Framework" data-animate="fadeInLeft">

						</div>



						<div class="col-lg-5">

							<div class="topmargin-lg d-none d-lg-block"></div>

							<img src="{{ asset('/frontend/images/section/section-1-icon.png') }}" alt="" style="display: block;" class="bottommargin-sm">

							<div class="emphasis-title bottommargin-sm">

								<span class="before-heading">Plug into the</span>

								<h2 style="font-size: 42px;" class="font-body ls1 t400">NextGen Framework</h2>

							</div>

							<p style="color: #777;" class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium, vel! Eius pariatur nemo expedita.</p>

							<a href="#" class="section-more-link">Learn More <i class="icon-angle-right"></i></a>

						</div>



					</div>

				</div>



				<div class="line"></div>

				<div class="clear"></div>



				<div id="section-stunning-graphics" class="page-section topmargin bottommargin-lg">

					<div class="row clearfix">



						<div class="col-lg-5">

							<div class="topmargin-lg d-none d-lg-block"></div>

							<img src="{{ asset('/frontend/images/section/section-2-icon.png') }}" alt="" style="display: block;" class="bottommargin-sm">

							<div class="emphasis-title bottommargin-sm">

								<span class="before-heading">Retina Ready &#x7E; 534 PPI</span>

								<h2 style="font-size: 42px;" class="font-body ls1 t400">Stunning Graphics</h2>

							</div>

							<p style="color: #777;" class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium, vel! Eius pariatur nemo expedita.</p>

							<a href="#" class="section-more-link">Learn More <i class="icon-angle-right"></i></a>

						</div>



						<div class="col-lg-7 center">

							<img src="{{ asset('/frontend/images/section/iphone-nexus.png') }}" alt="Stunning Graphics" data-animate="fadeInRight">

						</div>



					</div>

				</div>



				<div class="line"></div>

				<div class="clear"></div>



			</div>



			<div class="clear"></div>

			<div id="section-secured-solutions" class="page-section section nopadding topmargin-sm" style="background: url('./frontend/images/section/iphone-3d-bg.png') no-repeat left bottom; background-size: 100% auto;background: #F6F6F6 !important;" data-height-xl="700" data-height-lg="700" data-height-md="450" data-height-sm="450" data-height-xs="450">

				<div class="container clearfix">

					<div class="row clearfix">

						<div class="col-lg-5 offset-lg-6">

							<div class="topmargin-lg d-none d-lg-block"></div>

							<div class="topmargin-lg d-none d-lg-block"></div>

							<img src="{{ asset('/frontend/images/section/section-3-icon.png') }}" alt="" style="display: block;" class="bottommargin-sm">

							<div class="emphasis-title bottommargin-sm">

								<span class="before-heading">Privacy Protected</span>

								<h2 style="font-size: 42px;" class="font-body ls1 t400">Secured Solutions</h2>

							</div>

							<p style="color: #777;" class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium, vel! Eius pariatur nemo expedita.</p>

							<a href="#" class="section-more-link">Learn More <i class="icon-angle-right"></i></a>

						</div>

					</div>

				</div>

				<div class="video-wrap" style="position: absolute; height: 100%; z-index: 1;">

					<div class="video-overlay d-none d-lg-block" style="background: url('./frontend/images/section/iphone-3d.png') no-repeat left top; background-size: auto 100%;" data-animate="fadeInLeft"></div>

				</div>

			</div>

		</div>

		<!--Middle Section End-->



		<!--Slider Start-->

		<section id="slider" class="slider-element boxed-slider">

			<div class="container clearfix">

				<div id="oc-slider" class="owl-carousel carousel-widget" data-margin="0" data-items="1" data-animate-in="zoomIn" data-speed="450" data-animate-out="fadeOut">

					<a><img src="{{ asset('/frontend/images/slider/full/1.jpg') }}" alt="Slider"></a>

					<a><img src="{{ asset('/frontend/images/slider/full/2.jpg') }}" alt="Slider"></a>

					<a><img src="{{ asset('/frontend/images/slider/full/3.jpg') }}" alt="Slider"></a>

					<a><img src="{{ asset('/frontend/images/slider/full/4.jpg') }}" alt="Slider"></a>

				</div>

			</div>

		</section>

		<!--Slider End-->



		<!--Content Start-->

		<div class="container sales-section support" style="padding: 75px;">

			<div class="row">



				<div class="col-sm-6 col-md-4 col-lg-6 text-center">

					<i class="far fa-comments fa-5x"></i>

					<h3 class="primary-heading">FAST FRIENDLY SUPPORT</h3>

					<p class="desc">Have a question or need help? Our professional and experienced support team will help you solve your problems fast. There are no call centers, and nothing is outsourced.</p>

				</div>

				<div class="col-sm-6 col-md-4 col-lg-6 text-center">

					<i class="fas fa-cloud fa-5x"></i>

					<h3 class="primary-heading">BEST-IN-CLASS CLOUD HOSTING</h3>

					<p class="desc">All your Original, full-res images are stored with Amazon Web Services, the most reliable cloud hosting infrastructure. Your files are always secure and backed-up. </p>

				</div>

			</div>

		</div>

		<!--Content End-->

@endsection