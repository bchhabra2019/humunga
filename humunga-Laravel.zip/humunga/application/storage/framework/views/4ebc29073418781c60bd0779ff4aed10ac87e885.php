<?php $__env->startSection('content'); ?>

		<!-- Content
				============================================= -->
		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">

					<div class="col_one_fourth">
						<h2>Albums</h2>	
					</div>
					
					
					<div class="col_three_fourth col_last">						
						
						<div class="search-bar">							
							<input type="text" name="" id="" placeholder="Search" class="search-box">
							<button type="submit" name="submit" class="search_btn icon-search-1" value="Search"><i class="icon-search3"></i></button>
						</div>	

						<button class="button float-right button-rounded button-reveal" data-toggle="modal" data-target="#myModal1"><i class="icon-line-plus"></i><span>Add New</span></button>
							
					</div>	

					<!-- Post Content
							============================================= -->
					<div class="nobottommargin clearfix">

						<!-- Portfolio Filter
							============================================= -->
						<ul class="portfolio-filter clearfix" data-container="#portfolio">

							<li class="activeFilter"><a href="#" data-filter="*">Show All</a></li>
							<li><a href="#" data-filter=".pf-icons">Wedding</a></li>
							<li><a href="#" data-filter=".pf-illustrations">Engagement</a></li>
							<li><a href="#" data-filter=".pf-uielements">Church</a></li>
							<li><a href="#" data-filter=".pf-media">Party</a></li>
							<li><a href="#" data-filter=".pf-graphics">Graphics</a></li>

						</ul>
						<!-- #portfolio-filter end -->
						<div class="clearfix"></div>

						<!-- Portfolio Items
							============================================= -->
						<div id="portfolio" class="portfolio grid-container clearfix">

							<article class="col-md-3 center topmargin-sm pf-graphics">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="<?php echo e(asset('/frontend/images/7.jpg')); ?>" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Open Imagination</a></h3>
									<span><a href="#">Media</a>, <a href="#">Icons</a></span>
								</div>
							</article>


							<article class="col-md-3 center topmargin-sm pf-icons">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="<?php echo e(asset('/frontend/images/album/1.jpg')); ?>" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Open Imagination</a></h3>
									<span><a href="#">Media</a>, <a href="#">Icons</a></span>
								</div>
							</article>

							<article class="col-md-3 center topmargin-sm pf-icons">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="<?php echo e(asset('/frontend/images/album/3.jpg')); ?>" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Locked Steel Gate</a></h3>
									<span><a href="#">Illustrations</a></span>
								</div>
							</article>

							<article class="col-md-3 center topmargin-sm pf-media">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="<?php echo e(asset('/frontend/images/album/6.jpg')); ?>" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Mac Sunglasses</a></h3>
									<span><a href="#">Graphics</a>, <a href="#">UI Elements</a></span>
								</div>
							</article>

							<article class="col-md-3 center topmargin-sm pf-illustrations">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="<?php echo e(asset('/frontend/images/album/2.jpg')); ?>" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Morning Dew</a></h3>
									<span><a href="#">Icons</a>, <a href="#">Illustrations</a></span>
								</div>
							</article>

							<article class="col-md-3 center topmargin-sm pf-graphics">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="<?php echo e(asset('/frontend/images/album/4.jpg')); ?>" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Console Activity</a></h3>
									<span><a href="#">UI Elements</a>, <a href="#">Media</a></span>
								</div>
							</article>

							<article class="col-md-3 center topmargin-sm pf-illustrations">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="<?php echo e(asset('/frontend/images/album/8.jpg')); ?>" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Shake It!</a></h3>
									<span><a href="#">Illustrations</a>, <a href="#">Graphics</a></span>
								</div>
							</article>

							<article class="col-md-3 center topmargin-sm pf-graphics pf-uielements">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="<?php echo e(asset('/frontend/images/album/3.jpg')); ?>" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Shake It!</a></h3>
									<span><a href="#">Illustrations</a>, <a href="#">Graphics</a></span>
								</div>
							</article>

							<article class="col-md-3 center topmargin-sm pf-uielements">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="<?php echo e(asset('/frontend/images/album/6.jpg')); ?>" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Shake It!</a></h3>
									<span><a href="#">Illustrations</a>, <a href="#">Graphics</a></span>
								</div>
							</article>

							<article class="col-md-3 center topmargin-sm pf-graphics">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="<?php echo e(asset('/frontend/images/album/1.jpg')); ?>" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Shake It!</a></h3>
									<span><a href="#">Illustrations</a>, <a href="#">Graphics</a></span>
								</div>
							</article>

							<article class="col-md-3 center topmargin-sm pf-illustrations">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="<?php echo e(asset('/frontend/images/album/3.jpg')); ?>" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Shake It!</a></h3>
									<span><a href="#">Illustrations</a>, <a href="#">Graphics</a></span>
								</div>
							</article>

							<article class="col-md-3 center topmargin-sm pf-icons">
								<div class="portfolio-image img-shadow">
									<a href="#">
										<img src="<?php echo e(asset('/frontend/images/7.jpg')); ?>" alt="img05" style="">
									</a>
								</div>
								<div class="portfolio-desc">
									<h3><a href="portfolio-single-gallery.html">Shake It!</a></h3>
									<span><a href="#">Illustrations</a>, <a href="#">Graphics</a></span>
								</div>
							</article>

						</div>
						<!-- #portfolio end -->

					</div>

				</div>

			</div>

		</section>
		<!-- #content end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.frontend_inner_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>