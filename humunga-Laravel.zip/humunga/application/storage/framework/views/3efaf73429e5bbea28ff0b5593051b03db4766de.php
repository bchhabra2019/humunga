<?php $__env->startSection('content'); ?>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 margin-tb">
				<div class="pull-left">
					<h3>Website Setting</h3>
				</div>
			</div>
		</div>
		<?php if($message = Session::get('success')): ?>
			<div class="alert alert-success">
				<p><?php echo e($message); ?></p>
			</div>
		<?php endif; ?>
		<table class="table table-bordered">
			<tr>
				<th>Logo</th>
				<th>Email</th>
				<th>Phone</th>
				<th>Address</th>
				<th>Skype Address</th>
				<th>Action</th>
			</tr>
			<?php $__currentLoopData = $websitesetting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><img src="<?php echo e(url('admin/images/'.$res->logo)); ?>" width="100px" height="100px"></td>
				<td><?php echo e($res->email); ?></td>
				<td><?php echo e($res->phone); ?></td>
				<td><?php echo e($res->address); ?></td>
				<td><?php echo e($res->skype_address); ?></td>
				<td>
					<a href="<?php echo e(route('websitesetting.edit',$res->id)); ?>"><i class="fa fa-edit fa-2x text-info" title="Edit"></i></a>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>	   
	</div> <!-- container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>