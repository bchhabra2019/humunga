<div class="left-side-menu">

	<div class="slimscroll-menu">

		<!-- User box -->
		<div class="user-box text-center">
			<img src="<?php echo e(asset("/admin/images/users/user-1.jpg")); ?>" alt="user-1" class="rounded-circle img-thumbnail avatar-lg">
			<div class="dropdown">
				<a href="#" class="text-dark dropdown-toggle h5 mt-2 mb-1 d-block" data-toggle="dropdown"><?php echo e(Auth::user()->name); ?></a>
				<div class="dropdown-menu user-pro-dropdown">
					
					<!-- item-->
					<a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="dropdown-item notify-item">
						<i class="fe-log-out mr-1"></i>
						<span>Logout</span>
					</a>
					<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
						<?php echo csrf_field(); ?>
					</form>
				</div>
			</div>
			
		</div>

		<!--- Sidemenu -->
		<div id="sidebar-menu">

			<ul class="metismenu" id="side-menu">
				<!-- Dashboard -->
				<li id="Dashboard">
					<a href="<?php echo e(url('admin/dashboard')); ?>">
						<i class="mdi mdi-view-dashboard"></i>
						<span> Dashboard </span>
					</a>
				</li>				
				
				<!-- Home content -->
				<li>
					<a href="javascript: void(0);">
						<i class="mdi mdi-layers"></i>
						<span> Home Content </span>
						<span class="menu-arrow"></span>
					</a>
					<ul class="nav-second-level" aria-expanded="false">
						<li id="Slider">
							<a href="<?php echo e(url('admin/slider')); ?>">
								<span> Slider </span>
							</a>
						</li>
						<li id="Services">
							<a href="<?php echo e(url('admin/services')); ?>">
								<span> Services </span>
							</a>
						</li> 
						<li id="Sections">
							<a href="<?php echo e(url('admin/sections')); ?>">
								<span> Section Content </span>
							</a>
						</li> 
					</ul>
				</li>
				
				<!-- User list -->
				<li id="Members">
					<a href="<?php echo e(url('admin/members')); ?>">
						<i class="mdi mdi-layers"></i>
						<span> Members </span>
					</a>
				</li>
				<!-- // End-->
				
				<!-- Website setting -->
				<li id="Websitesetting">
					<a href="<?php echo e(url('admin/websitesetting')); ?>">
						<i class="mdi mdi-layers"></i>
						<span> Website Setting</span>
					</a>
				</li>	
				<?php
				/*
				<!-- Subscription list -->
				<li id="Subscription">
					<a href="{{ url('admin/subscription') }}">
						<i class="mdi mdi-layers"></i>
						<span> Subscription </span>
					</a>
				</li>
				
				<!-- User list -->
				<li id="Members">
					<a href="{{ url('admin/members') }}">
						<i class="mdi mdi-layers"></i>
						<span> Members </span>
					</a>
				</li>
				
				<!-- Email template -->
				<li id="Systememail">
					<a href="{{ url('admin/systememail') }}">
						<i class="mdi mdi-layers"></i>
						<span> System email </span>
					</a>
				</li>
				
				<!-- System pages -->
				<li id="Systempages">
					<a href="{{ url('admin/systempages') }}">
						<i class="mdi mdi-layers"></i>
						<span> System Pages </span>
					</a>
				</li>	
								
				*/
				?>			
			</ul>
		</div>
		<!-- End Sidebar -->
		<div class="clearfix"></div>
	</div>
	<!-- Sidebar -left -->
</div>