<?php $__env->startSection('content'); ?>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 margin-tb">
				<div class="pull-left">
					<h3> Show Member</h3>
				</div>
				<div class="pull-right add-btn">
					<a class="btn btn-primary" href="<?php echo e(route('members.index')); ?>"> Back</a>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-6 col-sm-6 col-md-6">
				<div class="form-group">
					<label>Name:</label>
					<p><?php echo e($member->name); ?></p>
				</div>
			</div>
			<div class="col-xs-6 col-sm-6 col-md-6">
				<div class="form-group">
					<label>Email:</label>
					<p><?php echo e($member->email); ?></p>
				</div>
			</div>
			<div class="col-xs-6 col-sm-6 col-md-6">
				<div class="form-group">
					<label>Plan:</label>
					<p><?php echo e(@$plan_details->plan_name); ?></p>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>