<!-- Header
		============================================= -->
		<header id="header" class="transparent-header full-header" data-sticky-class="not-dark">

			<div id="header-wrap">

				<div class="container clearfix">

					<div id="primary-menu-trigger"><i class="icon-reorder"></i></div>

					<!-- Logo
					============================================= -->
					<div id="logo">
						<a href="<?php echo e(url('home')); ?>" class="standard-logo" data-dark-logo="<?php echo e(asset('/frontend/images/logo-tex-blckt.png')); ?>">
							<img src="<?php echo e(asset('/frontend/images/logo-tex-blckt.png')); ?>" />
						</a>
						<a href="<?php echo e(url('home')); ?>" class="retina-logo" data-dark-logo="<?php echo e(asset('/frontend/images/logo-tex-blckt.png')); ?>">
							<img src="<?php echo e(asset('/frontend/images/logo-tex-blckt.png')); ?>" />
						</a>
					</div><!-- #logo end -->

					<!-- Primary Navigation
					============================================= -->
					<nav id="primary-menu">
						<ul>
							<li id="Tour">
								<a href="<?php echo e(url('tour')); ?>"><div>Features</div></a>
							</li>
							<li id="Example">
								<a href="<?php echo e(url('example')); ?>"><div>Examples</div></a>
							</li>
							<li id="Upgrade">
								<a href="<?php echo e(url('upgrade')); ?>"><div>Upgrade</div></a>
							</li>
							<?php if(Session::get('ID')): ?>
								<li id="Dashboard" class="current">
									<a href="<?php echo e(url('/album')); ?>"><div><?php echo e(Session::get('uname')); ?></div></a>
								</li>				
								<li>
									<a href="<?php echo e(url('/logout')); ?>"><div>Logout</div></a>
								</li>							
							<?php else: ?>
								<li id="Login">
									<a href="<?php echo e(url('signin')); ?>"><div>LOGIN</div></a>
								</li>
								<li id="SignUp">
									<a href="<?php echo e(url('signup')); ?>"><div>SIGNUP</div></a>
								</li>
							<?php endif; ?>	
						</ul>						
						<!-- Top Search
						============================================= -->						
					</nav><!-- #primary-menu end -->

				</div>

			</div>

		</header><!-- #header end -->