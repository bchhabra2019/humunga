<?php $__env->startSection('content'); ?>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 margin-tb">
				<div class="pull-left">
					<h3>Home Section</h3>
				</div>
			</div>
		</div>
		<?php if($message = Session::get('success')): ?>
			<div class="alert alert-success">
				<p><?php echo e($message); ?></p>
			</div>
		<?php endif; ?>
		<table class="table table-bordered">
			<tr>
				<th>Section name</th>
				<th>Title</th>
				<th>Description</th>
				<th width="10%">Action</th>
			</tr>
			<?php if($services_resut): ?>
				<?php $__currentLoopData = $services_resut; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>										
					<td><?php echo e($res->section_name); ?></td>
					
					<td><?php echo e($res->title); ?></td>
					
					<td><?php echo e($res->description); ?></td>
					<td >
						<a href="<?php echo e(route('sections.edit',$res->id)); ?>"><i class="fa fa-edit fa-2x text-info" title="Edit"></i></a>						
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php else: ?>
				<tr>
					<td colspan="3">No recode found</td>
				</tr>
			<?php endif; ?>
		</table>	   
	</div> <!-- container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>