	

<?php $__env->startSection('content'); ?>
	<div class="content-wrap notoppadding nobottompadding">
		<!-- WE are Snapics -->
		<div class="section nobottommargin notopmargin bgcolor-black aboutme-note">
			<div class="container clear-bottommargin clearfix">
				<div class="row topmargin-sm clearfix">
					<div class="col-lg-6 bottommargin border-right">
						<p class="topmargin-sm font-white">
							<?php echo $home_resut[0]->description; ?>

						</p>
					</div>

					<div class="col-lg-6 bottommargin">
						<div class="emphasis-title">
							<h2 class="font-white" style="text-align: center;padding-top: 40px;"><strong><?php echo $home_resut[0]->title; ?></strong></h2>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--//-->
		<!---->
		<?php if($slider_resut): ?>
			<div class="parallax-bg-1">
				<div class="section parallax full-screen nomargin noborder" style="background-image: url('./frontend/images/parallax-3.png') top center;" data-bottom-top="background-position:0px 0px;" data-top-bottom="background-position:0px 0px;">
					<div class="vertical-middle">
						<div class="container clearfix">
							<div class="col_full nobottommargin">
								<div id="oc-images" class="owl-carousel image-carousel carousel-widget" data-margin="20" data-nav="true" data-pagi="true" data-items-xs="1" data-items-sm="1" data-items-lg="1" data-items-xl="1">									
									<!-- Mini slider -->
									<?php $__currentLoopData = $slider_resut; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($res->type == 'Mini'): ?>
											<div class="oc-item">
												<div class="col_two_fifth">
													<div class="emphasis-title font-white">
														<h3 class="font-white"><?php echo $res->title; ?></h3>
														<p class="lead topmargin-sm"><?php echo $res->description; ?></p>
													</div>
												</div>
												<div class="col_three_fifth col_last">
													<img src="<?php echo e(asset('application/public/admin/images/'.$res->image)); ?>" class="img-responsive">
												</div>
											</div>											
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>									
									<!--//-->									
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php endif; ?>
		<!--//-->	
		<!-- Features -->
		<div class="nobottommargin notopmargin bgcolor-black aboutme-note">
			<div class="section parallax parallax-bg nomargin notopborder" data-rellax-speed="2" style="background: url('./frontend/images/parallax-5.png') center center; padding: 100px 0; background-size:cover " data-bottom-top="background-position:0px 0px;" data-top-bottom="background-position:0px 0px;">
				<div class="container clear-bottommargin clearfix">
					<div class="row topmargin-sm clearfix">
						<div class="clear"></div>
						<div class="col_one_third">
							<div class="feature-box fbox-center fbox-dark fbox-plain">
								<div class="fbox-icon">	
									<a href="#">
										<img src="<?php echo e(asset('application/public/admin/images/'.$services_resut[0]->icon)); ?>">
									</a>
								</div>
								<h3 class="font-white"><?php echo e(strip_tags($services_resut[0]->name)); ?></h3>
								<p><?php echo e(strip_tags($services_resut[0]->description)); ?></p>
							</div>
						</div>

						<div class="col_one_third">
							<div class="feature-box fbox-center fbox-dark fbox-plain">
								<div class="fbox-icon">	
									<a href="#">
										<img src="<?php echo e(asset('application/public/admin/images/'.$services_resut[1]->icon)); ?>">
									</a>
								</div>
								<h3 class="font-white"><?php echo e(strip_tags($services_resut[1]->name)); ?></h3>
								<p><?php echo e(strip_tags($services_resut[1]->description)); ?></p>
							</div>
						</div>

						<div class="col_one_third col_last">
							<div class="feature-box fbox-center fbox-dark fbox-plain">
								<div class="fbox-icon">	
									<a href="#">
										<img src="<?php echo e(asset('application/public/admin/images/'.$services_resut[2]->icon)); ?>">
									</a>
								</div>
								<h3 class="font-white"><?php echo e(strip_tags($services_resut[2]->name)); ?></h3>
								<p><?php echo e(strip_tags($services_resut[2]->description)); ?></p>
							</div>
						</div>
					</div>	
				</div>						
			</div>
			<!--//-->
			<div class="clear"></div>
			<!-- WE are Snapics -->
			<div class="section nobottommargin notopmargin aboutme-note parallax-bg-1">
				<div class="container clear-bottommargin clearfix">
					<div class="row topmargin-sm clearfix">
						<div class="col-lg-6 bottommargin border-right">
							<p class="topmargin-sm font-white">
								<?php echo $home_resut[1]->description; ?>

							</p>
						</div>
						<div class="col-lg-6 bottommargin">
							<div class="emphasis-title">
								<h2 class="font-white"><strong><?php echo $home_resut[1]->title; ?></strong></h2>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>	
	<!-- Content
    ============================================= -->
	<div class="section parallax dark nomargin noborder" style="padding: 150px 0; background-image: url('./frontend/images/footer.jpg');" data-bottom-top="background-position:0px 0px;" data-top-bottom="background-position:0px -300px;">
		<div class="container center clearfix">
			<div class="emphasis-title">
				<h2><?php echo e(strip_tags($home_resut[2]->title)); ?></h2>
				<?php echo e(strip_tags($home_resut[2]->description)); ?>

			</div>
		</div>
	</div>
	<!-- #content end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.frontend_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>