<?php $__env->startSection('content'); ?>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 margin-tb">								
				<div class="pull-left">					
					<h3>Member</h3>
				</div>	
				<div class="pull-right add-btn">
					<a class="btn btn-success" href="<?php echo e(route('members.create')); ?>" title="Member"> Create New</a>
				</div>
			</div>
		</div>
		<?php if($message = Session::get('success')): ?>
			<div class="alert alert-success">
				<p><?php echo e($message); ?></p>
			</div>
		<?php endif; ?>
		<table id="datatable" class="table table-bordered dt-responsive nowrap">
			<thead>
				<tr>
					<th>No</th>
					<th>Image</th>
					<th>Name</th>
					<th>Email</th>
					<th>Contact</th>
					<th>Plan name</th>
					<th width="80px">Action</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr class="item<?php echo e($product->id); ?>">
					<td><?php echo e(++$i); ?></td>
					<td><img src="<?php echo e(url('admin/images/'.$product->image)); ?>" alt="<?php echo e($product->image); ?>" width="100px" height="100px"></td>
					<td><?php echo e($product->name); ?></td>
					<td><?php echo e($product->email); ?></td>
					<td><?php echo e($product->phone); ?></td>
					<td>
						<?php if($plan_details): ?>
							<?php $__currentLoopData = $plan_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($res->user_id == $product->id): ?>
									<span><?php echo e($res->plan_name); ?></span>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</td>
					<td>
						<form action="<?php echo e(route('members.destroy',$product->id)); ?>" method="POST">
							<a href="<?php echo e(route('members.show',$product->id)); ?>"><i class="fa fa-th-list fa-2x text-primary" title="Show"></i></a>
							<a href="<?php echo e(route('members.edit',$product->id)); ?>"><i class="fa fa-edit text-info fa-2x" title="Edit"></i></a>
							<?php echo csrf_field(); ?>
							<?php echo method_field('DELETE'); ?>	   
							<button type="submit" class="form-icon"><i class="fa fa-trash fa-2x text-danger" title="Delete"></i></button>
						</form>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
		<?php echo $member->links(); ?>		   
	</div> <!-- container -->
	<script>
		$(document).ready(function() {
			$('#datatable').DataTable();
		} );
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>