<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h3><?php echo $heading; ?> </h3>
		<div>
			<p><strong>Dear <?php echo $name; ?></strong>,</p>
			<p>Welcome to Snapice!</p>
			<p>Login details: 	</p>
			<p>Username: <b><?php echo $Email; ?></b></p>
			<p>Password: <b><?php echo $Password; ?></b></p>
			<p>Snapics team</p>
		</div>
	</body>
</html>