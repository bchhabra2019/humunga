<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>

	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="author" content="SemiColonWeb" />
	<meta name="current-menu" content="<?php echo e($Active_menu); ?>">	
	<!-- Stylesheets
	============================================= -->
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700|Raleway:300,400,500,600,700|Crete+Round:400i" rel="stylesheet" type="text/css" />
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="<?php echo e(asset('/frontend/css/bootstrap.css')); ?>" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(asset('/frontend/css/style.css')); ?>" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(asset('/frontend/css/swiper.css')); ?>" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(asset('/frontend/css/dark.css')); ?>" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(asset('/frontend/css/font-icons.css')); ?>" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(asset('/frontend/css/animate.css')); ?>" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(asset('/frontend/css/bs-switches.css')); ?>" type="text/css" />
	
	<link rel="stylesheet" href="<?php echo e(asset('/frontend/css/components/datepicker.css')); ?>" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(asset('/frontend/css/components/timepicker.css')); ?>" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(asset('/frontend/css/components/daterangepicker.css')); ?>" type="text/css" />
	
	<link rel="stylesheet" href="<?php echo e(asset('/frontend/css/magnific-popup.css')); ?>" type="text/css" />

	<link rel="stylesheet" href="<?php echo e(asset('/frontend/css/responsive.css')); ?>" type="text/css" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	<!-- Document Title
	============================================= -->
	<title><?php echo e(isset($page_title) ? $page_title : "Humunga"); ?></title>

</head>

<body class="stretched" id="inner-pages">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

		<?php echo $__env->make('Frontend.layout.header_inner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		
			<?php echo $__env->yieldContent('content'); ?>

		<?php echo $__env->make('Frontend.layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		
	</div><!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="icon-angle-up"></div>

	<!-- External JavaScripts
	============================================= -->
	<script src="<?php echo e(asset('/frontend/js/jquery.js')); ?>"></script>
	<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
	<script>
		$(function() {	
			$('.travel-date-group .today').datepicker({
				autoclose: true,
				startDate: "today",
				formate: "dd-mm-yyyy",
				todayHighlight: true
			});
			$('.travel-date-group .input-daterange').datepicker({
				autoclose: true
			});
		});	
	</script>
	<script>
		<?php if(Session::has('message')): ?>
			var type = "<?php echo e(Session::get('alert-type', 'info')); ?>"
			switch(type){
				case 'info':
					toastr.info("<?php echo e(Session::get('message')); ?>");	
					break;
				case 'success':
					toastr.success("<?php echo e(Session::get('message')); ?>");	
					break;
				case 'error':
					toastr.error("<?php echo e(Session::get('message')); ?>");	
					break;
				case 'warning':
					toastr.warning("<?php echo e(Session::get('message')); ?>");	
					break;
			}
		<?php endif; ?>
	</script>
	<script src="<?php echo e(asset('/frontend/js/plugins.js')); ?>"></script>

	<!-- Footer Scripts
	============================================= -->
	
	<!-- Date & Time Picker JS -->
	<script src="<?php echo e(asset('/frontend/js/components/moment.js')); ?>"></script>
	<script src="<?php echo e(asset('/frontend/js/components/datepicker.js')); ?>"></script>
	<script src="<?php echo e(asset('/frontend/js/components/timepicker.js')); ?>"></script>
	
	<!-- Include Date Range Picker -->
	<script src="<?php echo e(asset('/frontend/js/components/daterangepicker.js')); ?>"></script>
	
	<script src="<?php echo e(asset('/frontend/js/functions.js')); ?>"></script>
	<script src="<?php echo e(asset('/frontend/js/switcher.js')); ?>"></script>
	<script>
		$(document).ready(function(){
			var element = $('meta[name="current-menu"]').attr('content');
			$('#' + element).addClass('current');
		});
		
		function validationAlbum()
		{
			var album_name = $("#album_name").val();
			var create_date = $("#create_date").val();
			var album_tag = $("#album_tag").val();
			var expiry_date = $("#expiry_date").val();
			if(album_name == '')
			{
				toastr.warning("Album name is required");
				$("#album_name").focus();
				return false;
			}
			if(create_date == '')
			{
				toastr.warning("Date is required");	
				$("#create_date").focus();
				return false;
			}
			if(album_tag == '')
			{
				toastr.warning("Album tag is required");	
				$("#album_tag").focus();
				return false;
			}
			if(album_name != '' && create_date != '' && album_tag != '' && expiry_date != '')
			{
				var dataString = 'name='+album_name+'&create_date='+create_date+'&album_tag='+album_tag+'&expiry_date='+expiry_date;
				// $.ajax({
					// url : host+'/createAlbum'
				// });
				toastr.success("Album create successfull");	
				return true;
			}
			else
			{
				toastr.warning("All field are required");	
				return false;
			}
		}
	</script>
</body>
</html>