<?php $__env->startSection('content'); ?>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 margin-tb">
				<div class="pull-left">
					<h3>Edit Details</h3>
				</div>
				<div class="pull-right add-btn">
					<a class="btn btn-primary" href="<?php echo e(route('websitesetting.index')); ?>"> Back</a>
				</div>
			</div>
		</div>

		<?php if($errors->any()): ?>
			<div class="alert alert-danger">
				<strong>Whoops!</strong> There were some problems with your input.<br><br>
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		<?php endif; ?>

		<form action="<?php echo e(route('websitesetting.update',$websitesetting_details->id)); ?>" method="POST" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			<?php echo method_field('PUT'); ?>

			 <div class="row">
				<div class="col-xs-3 col-sm-3 col-md-3">
					<div class="form-group">
						<strong>Logo</strong>
						<img src="<?php echo e(url('admin/images/'.$websitesetting_details->logo)); ?>" width="100" height="100">
					</div>
				</div>
				<div class="col-xs-3 col-sm-3 col-md-3">
					<div class="form-group">
						<strong>Change</strong>
						<input type="file" name="logo" />
					</div>
				</div>
				<div class="col-xs-6 col-sm-6 col-md-6">
					<div class="form-group">
						<strong>Email<sup class="text-danger">*</sup></strong>
						<input type="email" name="email" value="<?php echo e($websitesetting_details->email); ?>" class="form-control">
					</div>
				</div>
				<div class="col-xs-6 col-sm-6 col-md-6">
					<div class="form-group">
						<strong>Phone<sup class="text-danger">*</sup></strong>
						<input type="number" name="phone" value="<?php echo e($websitesetting_details->phone); ?>" class="form-control">
					</div>
				</div>
				<div class="col-xs-6 col-sm-6 col-md-6">
					<div class="form-group">
						<strong>Skype address<sup class="text-danger">*</sup></strong>
						<input type="text" name="skype_address" value="<?php echo e($websitesetting_details->skype_address); ?>" class="form-control">
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Address<sup class="text-danger">*</sup></strong>
						<input type="text" name="address" value="<?php echo e($websitesetting_details->address); ?>" class="form-control">
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
				  <button type="submit" class="btn btn-success">Update</button>
				</div>
			</div>
		</form>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>